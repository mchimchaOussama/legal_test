<div>

    <?php $__env->startSection("title"); ?>
    Villes
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
    VILLES
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("element"); ?>
        <button role="button" class="btn btn-primary px-2 add-modal">Ajouter Ville</button>
    <?php $__env->stopSection(); ?>


    <div class="card">
        <div class="card-body py-1 px-0">

            <table class="custom-table w-100">
                <thead>
                    <th>Ville</th>
                    <th>Code postale</th>
                    <th>Leads</th>
                    <th>Action</th>
                </thead>
                <tbody class="custom-striped">

                    <!--[if BLOCK]><![endif]--><?php if($villes->count() == 0): ?>
                        <tr>
                            <td colspan="5" class="text-center">Aucune ville</td>
                        </tr>
                    <?php else: ?>

                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ville->ville); ?></td>
                                <td><?php echo e($ville->code_postale->code_postale); ?></td>
                                <td><?php echo e($ville->leads_count); ?></td>
                                <td>

                                    <a href="#" title="Modifier" class="edit-modal" wire:click="modifier_ville(<?php echo e($ville->id); ?>)">
                                        <i class="fa-solid fa-pen-clip fa-lg text-secondary mr-1"></i>
                                    </a>
                                    <a href="#" title="Supprimer" wire:click="delete_ville(<?php echo e($ville->id); ?>)">
                                        <i class="fa-solid fa-trash-can fa-lg text-danger"></i>
                                    </a>

                                </td>  
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                </tbody>
            </table>
            </div>
              <!-- Pagination Links -->
              <div class="d-flex  mt-1 mx-2">
                  <div class="btn-group" role="group">
                      <?php echo e($villes->links('pagination::bootstrap-4')); ?>

                  </div>
              </div>
          </div>

          <?php echo $__env->make('livewire.admin.ville.ajouter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo $__env->make('livewire.admin.ville.modifier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div><?php /**PATH C:\Users\USER\Desktop\leads-app-2\resources\views/livewire/admin/ville/index.blade.php ENDPATH**/ ?>