<div>

<?php $__env->startSection("title"); ?>
        Ajouter un Lead
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
        AJOUTER UN LEAD
    <?php $__env->stopSection(); ?>

        <div class="card">
            <div class="card-body py-0">

                    <div class="form-wizard">

                        <div class="form-wizard-header py-3">

                            <div class="form-wizard-header-box mb-2 <?php if($step == 1): ?> active <?php endif; ?>">
                                <div class="step">1</div>
                                <div class="title">Prospect</div>
                            </div>

                            <div class="form-wizard-header-box mb-2 <?php if($step == 2): ?> active <?php endif; ?>">
                                <div class="step">2</div>
                                <div class="title">L'appel</div>
                            </div>

                            <div class="form-wizard-header-box mb-2 <?php if($step == 3): ?> active <?php endif; ?>">
                                <div class="step">3</div>
                                <div class="title">Localisation</div>
                            </div>

                            <div class="form-wizard-header-box mb-2 <?php if($step == 4): ?> active <?php endif; ?>">
                                <div class="step">4</div>
                                <div class="title">Lead</div>
                            </div>

                            <div class="form-wizard-header-box mb-0 <?php if($step == 5): ?> active <?php endif; ?>">
                                <div class="step">5</div>
                                <div class="title">Publicité</div>
                            </div>
                            

                        </div>

                        <div class="form-wizard-body-container">
                            
                            <!---------- Step 1 ----------->
                            <!--[if BLOCK]><![endif]--><?php if($step == 1): ?>
                            <form  wire:submit="ajouter_lead_step1" autocomplete="off">
                                <div class="form-wizard-body py-3 active">

                                    <div class="h2 mb-2">Prospect</div>

                                    <!------ Row --------->
                                    <div class="row mb-2">


                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Nom</label>
                                                <input type="text" class="form-control  <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le nom" wire:model="nom" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["nom"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Prénom</label>
                                                <input type="text" class="form-control <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le prénom" wire:model="prenom" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["prenom"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Tel</label>
                                                <input type="number" class="form-control <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie tel" wire:model="tel" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["tel"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Email</label>
                                                <input type="text" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie l'email" wire:model="email" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Civilité</label>
                                                <select class="form-control <?php $__errorArgs = ['civilite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="civilite">
                                                    <option value="" selected>Civilité</option>
                                                    <option value="Mr" >Mr</option>
                                                    <option Value="Mme" >Mme</option>
                                                </select>
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["civilite"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>



                                    </div>
                                    <!------ End Row ------>

                                </div>

                                <!---- Pagination ---->
                                <div class="w-100 d-flex justify-content-between align-items-center form-wizard-pagination">
                                    <button class="prev btn btn-secondary btn-pagination" type="button" wire:click="previousSection">Précédent</button>

                                    <button class="next btn btn-secondary btn-pagination" type="submit">Suivant</button>
                                </div>
                                <!--- End Pagination --->

                            </form>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!---------- End Step 1 ----------->


                            <!---------- Step 2 ----------->
                            <!--[if BLOCK]><![endif]--><?php if($step == 2): ?>
                            <form  wire:submit="ajouter_lead_step2" autocomplete="off">
                                <div class="form-wizard-body py-3">

                                    <div class="h2 mb-2">L'appel</div>

                                    <!------- Row ---------->
                                    <div class="row mb-2">

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Agent</label>
                                                <input type="text" class="form-control  <?php $__errorArgs = ['agent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="agent" wire:model="agent" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["agent"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Heure</label>
                                                <input type="time" class="form-control <?php $__errorArgs = ['heure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le prénom" wire:model="heure" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["heure"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Date</label>
                                                <input type="date" class="form-control  <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie la date" wire:model="date" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">

                                                <label>Disponibilité</label>
                                                <select class="form-control <?php $__errorArgs = ['disponibilite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="disponibilite">
                                                    <option value="">Sélectionner</option>
                                                    <option value="matin">Matin</option>
                                                    <option value="apres midi">Aprés midi</option>
                                                </select>
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["disponibilite"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>

                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Appel d'Agent (Lien d'Audio)</label>
                                                <input type="text" class="form-control <?php $__errorArgs = ['lienMp3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le lien d'audio" wire:model="lienMp3" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["lienMp3"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Commentaire Agent</label>
                                                <input type="text" class="form-control <?php $__errorArgs = ['commentaireAgent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le commentaire" wire:model="commentaireAgent" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["commentaireAgent"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>


                                    </div>
                                    <!------- End Row --------->

                                </div>
                                <!---- Pagination ---->
                                <div class="w-100 d-flex justify-content-between align-items-center form-wizard-pagination">
                                    <button class="prev btn btn-secondary btn-pagination" type="button" wire:click="previousSection">Précédent</button>

                                    <button class="next btn btn-secondary btn-pagination" type="submit">Suivant</button>
                                </div>
                                <!--- End Pagination --->
                            </form>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!------- End Step 2 --------->


                            <!--------- Step 3---------->
                            <!--[if BLOCK]><![endif]--><?php if($step == 3): ?>
                            <form  wire:submit="ajouter_lead_step3" autocomplete="off">

                                <div class="form-wizard-body py-3">

                                    <div class="h2 mb-2">Localisation</div>

                                    <!------- Row -------->
                                    <div class="row mb-2">

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Ville</label>
                                                
                                                <select class="form-control <?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        wire:model="ville"
                                                        data-live-search="true"
                                                        data-style="form-control"
                                                        title="Sélectionner une ville">
                                                    <option   selected="">Sélectionner</option>  
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ville_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value='<?php echo e($Ville->id); ?>'><?php echo e($Ville->ville); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Département</label>
                                                <select class="form-control  <?php $__errorArgs = ['departement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        wire:model="departement"
                                                        data-live-search="true"
                                                        data-style="form-control"
                                                        title="Sélectionner une departement">
                                                    <option  selected=''>Sélectionner</option>  
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $departement_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Departement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value='<?php echo e($Departement->id); ?>'><?php echo e($Departement->departement); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["departement"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Code Postale</label>
                                                <input type="number" class="form-control  <?php $__errorArgs = ['code_postale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le code postale" wire:model="code_postale" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["code_postale"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Propriétaire</label>
                                                <select class="form-control <?php $__errorArgs = ['proprietaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="proprietaire">
                                                    <option value="">Sélectionner</option>
                                                    <option value="oui">Oui</option>
                                                    <option value="non">Non</option>
                                                </select>
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["proprietaire"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Métrage</label>
                                                <input type="number" class="form-control  <?php $__errorArgs = ['metrage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le métrage" wire:model="metrage" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["metrage"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Adresse</label>
                                                <input type="text" class="form-control  <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie l'adresse" wire:model="adresse" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["adresse"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>


                                    </div>

                                </div>

                                <!---- Pagination ---->
                                <div class="w-100 d-flex justify-content-between align-items-center form-wizard-pagination">
                                    <button class="prev btn btn-secondary btn-pagination" type="button" wire:click="previousSection">Précédent</button>

                                    <button class="next btn btn-secondary btn-pagination" type="submit">Suivant</button>
                                </div>
                                <!--- End Pagination --->

                            </form>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--------- End Step 3 ----------->


                            <!--------- Step 4---------->
                            <!--[if BLOCK]><![endif]--><?php if($step == 4): ?>
                            <form  wire:submit="ajouter_lead_step4" autocomplete="off">
                                <div class="form-wizard-body py-3">

                                    <div class="h2 mb-2">Lead</div>

                                    <!------- Row -------->
                                    <div class="row mb-2">

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Thématique</label>
                                                <select class="form-control  <?php $__errorArgs = ['thematique'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        wire:model="thematique"
                                                        data-live-search="true"
                                                        data-style="form-control"
                                                        title="Sélectionner une thématique">
                                                    <option   selected=''>Sélectionner</option>
                                                    
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $thematique_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Thematique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value='<?php echo e($Thematique->id); ?>'><?php echo e($Thematique->thematique); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["thematique"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Mode Consomation</label>
                                                <input type="text" class="form-control <?php $__errorArgs = ['modeConsommation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le mode de consommation" wire:model="modeConsommation" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["modeConsommation"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Commentaire Auditeur</label>
                                                <input type="text" class="form-control  <?php $__errorArgs = ['commentaireAuditeur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le commentaire" wire:model="commentaireAuditeur" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["commentaireAuditeur"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Audio Bipé (Lien)</label>
                                                <input type="text" class="form-control <?php $__errorArgs = ['lienMp3bip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le lien" wire:model="lienMp3bip" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["lienMp3bip"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Adresse cachée (Google Map)</label>
                                                <input type="text" class="form-control <?php $__errorArgs = ['adresse_cache'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie l'iFrame" wire:model="adresse_cache" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["adresse_cache"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>

                                    </div>

                                </div>

                                <!---- Pagination ---->
                                <div class="w-100 d-flex justify-content-between align-items-center form-wizard-pagination">
                                    <button class="prev btn btn-secondary btn-pagination" type="button" wire:click="previousSection">Précédent</button>
                                    <button class="next btn btn-secondary btn-pagination" type="submit">Suivant</button>
                                </div>
                                <!--- End Pagination --->
                            </form>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--------- End Step 4 ----------->


                            <!--------- Step 5---------->
                            <!--[if BLOCK]><![endif]--><?php if($step == 5): ?>
                            <form  wire:submit="ajouter_lead_step5" autocomplete="off">
                                <div class="form-wizard-body py-3">

                                    <div class="h2 mb-2">Publicité</div>

                                    <!------- Row -------->
                                    <div class="row mb-2">


                                        <div class="w-100"></div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Prix</label>
                                                <input type="number" class="form-control <?php $__errorArgs = ['prix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie le prix" wire:model="prix" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["prix"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group mb-1">
                                                <label>Adresse Réelle (Google Map)</label>
                                                <input type="text" class="form-control  <?php $__errorArgs = ['adresse_reelle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie l'iframe'" wire:model="adresse_reelle" autocomplete="off" />
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["adresse_reelle"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                            <div class="form-group" style="margin-bottom:10px">
                                                <label>Description</label>
                                                <textarea class="form-control" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie la description" wire:model="description" autocomplete="off" rows="5"></textarea>
                                                <span class="error">
                                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>
                                            </div>
                                        </div>

                                    </div>

                                </div>

                                <!---- Pagination ---->
                                <div class="w-100 d-flex justify-content-between align-items-center form-wizard-pagination">
                                    <button class="prev btn btn-secondary btn-pagination" type="button" wire:click="previousSection">Précédent</button>
                                    <!--[if BLOCK]><![endif]--><?php if($step == $maxSteps): ?>
                                        <button class="form-wizard-submit custom-btn" type="submit">Ajouter</button>
                                    <?php else: ?>
                                        <button class="next btn btn-secondary btn-pagination" type="submit">Suivant</button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <!--- End Pagination --->
                            </form>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--------- End Step 5 ----------->






                        </div>

                    </div>

                </form>


            </div>
        </div>
    </form>

</div><?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app-2\resources\views/livewire/admin/lead-ajouter/index.blade.php ENDPATH**/ ?>