    <!--------- Edit Modal ------------>
    <div wire:ignore.self class="modal fade" id="editModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header text-center">
                        <div class="w-100 text-center">
                            <div class="w-100 mb-1">
                                <i class="fa-regular fa-pen-to-square text-secondary"></i>
                            </div>
                            <h4 class="modal-title text-secondary">Modifier Compte</h4>
                        </div>
                    </div>
                    <div class="modal-body pb-2">

                        <form wire:submit="modifier_user_yes" class="w-100">

                            <div class="mb-1">
                                <label class="form-label mb-0">Nom:</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['new_nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="new_nom" >
                                <span class="error"><!--[if BLOCK]><![endif]--><?php $__errorArgs = ["new_nom"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]--></span>
                            </div>

                            <div class="mb-1">
                                <label class="form-label mb-0">Prénom:</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['new_prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="new_prenom" >
                                <span class="error"><!--[if BLOCK]><![endif]--><?php $__errorArgs = ["new_prenom"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]--></span>
                            </div>

                            <div class="mb-1">
                                <label class="form-label mb-0">Nom d'utilisateur:</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['new_nom_utilisateur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="new_nom_utilisateur" >
                                <span class="error"><!--[if BLOCK]><![endif]--><?php $__errorArgs = ["new_nom_utilisateur"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]--></span>
                            </div>

                            <div class="mb-1">
                                <label>Rôle</label>
                                <select class="form-control <?php $__errorArgs = ['new_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="new_role">
                                    <option value="" >Sélectionner un rôle</option>
                                    <option value="1">Administrateur</option>
                                    <option value="2">Superviseur</option>
                                </select>
                                <span class="error">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["new_role"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </span>
                            </div>

                            <div class="mb-1">
                                <label class="form-label mb-0">Mot de passe:</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="new_password" >
                                <span class="error"><!--[if BLOCK]><![endif]--><?php $__errorArgs = ["new_password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]--></span>
                            </div>

                            <div class="mb-1">
                                <label class="form-label mb-0">Confirmez mot de passe:</label>
                                <input type="text" class="form-control" wire:model="new_password_confirmation" >
                                <span class="error"></span>
                            </div>


                            <button type="submit" class="custom-btn w-100" wire:loading.class="disabled">
                                <div wire:loading><span class="spinner"></span></div>
                                <div wire:loading.remove>Modifier</div>
                            </button>

                        </form>

                    </div>
                </div>
            </div>
        </div><?php /**PATH D:\leads-app\resources\views/livewire/admin/administrateurs/edit.blade.php ENDPATH**/ ?>