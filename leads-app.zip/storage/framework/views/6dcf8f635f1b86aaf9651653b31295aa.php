
<div wire:ignore.self class="modal fade" id="addModal">
            <div class="modal-dialog" role="document">
              <div class="modal-content">

                <div class="w-100 text-center pt-3 mb-2">
                  <div class="w-100">
                  <div class="h3">Ajouter ville</div>
                  </div>
                </div>
                
                <form wire:submit="ajouter_ville" autocomplete="off">

                <div class="modal-body pb-0">

                    <div class="row">

                    <div class="col-12 mb-3">
                        <!-- header media -->
                        <div class="media">
                            <a href="javascript:void(0);" class="mr-25">
                              <!--[if BLOCK]><![endif]--><?php if($image): ?>
                                  <img src="<?php echo e($image->temporaryUrl()); ?>" id="account-upload-img" class="rounded mr-50" alt="profile image" height="80" width="80" />
                              <?php else: ?>
                                  <img src="<?php echo e(asset('/assets/images/produit.png')); ?>" id="account-upload-img" class="rounded mr-50" alt="profile image" height="80" width="80" />
                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </a>
                            <!-- upload and reset button -->
                            <div class="media-body mt-75 ml-1">
                                <label for="account-upload" class="btn btn-sm btn-primary mb-75 mr-75">Télécharger</label>
                                <input type="file" id="account-upload" hidden accept="image/png, image/jpg, image/jpeg" wire:model="image" />
                                <button class="btn btn-sm btn-outline-secondary mb-75" wire:click="supprimer_image">Supprimer</button>
                                <span class="d-block">JPG, JPEG ou PNG autorisé.</span>
                            </div>
                            <!--/ upload and reset button -->
                        </div>
                        <!--/ header media -->
                      </div>

                      <div class="col-12">
                          <div class="form-group mb-1">
                              <label>ville</label>
                              <input type="text" class="form-control  <?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie la ville" wire:model="ville" autocomplete="off" />
                              <span class="error">
                                  <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["ville"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                              </span>
                          </div>
                      </div>
                      <div class="col-12">
                          <div class="form-group mb-1">
                              <label>code postale</label>
                              <input type="text" class="form-control  <?php $__errorArgs = ['code_postale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie code postale" wire:model="code_postale" autocomplete="off" />
                              <span class="error">
                                  <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["code_postale"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                              </span>
                          </div>
                      </div>

                      <div class="col-12">
                          <div class="form-group mb-1">
                              <label>distinct</label>
                              <select class="form-control" wire:model="featured">
                                <option value="0" selected>Non</option>
                                <option value="1" >Oui</option>
                              </select>
                          </div>
                      </div>

                    </div>

                  </div>

                  <div class="modal-footer">
                    <button type="submit" class="custom-btn" wire:loading.class="disabled">  
                        <div wire:loading><span class="spinner"></span></div>
                        <span wire:loading.remove>Ajouter</span>
                    </button>
                  </div>

                </form>
                
              </div>
            </div>
          </div>
          <!----------------- End Modal -----------------><?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app\resources\views/livewire/admin/ville/ajouter.blade.php ENDPATH**/ ?>