<div>

    <?php $__env->startSection("title"); ?>
        Leads
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
        LEADS
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("element"); ?>
        <a role="button" class="btn btn-primary" href="<?php echo e(route('admin.lead-ajouter')); ?>" wire:navigate>Ajouter un Lead</a>
    <?php $__env->stopSection(); ?>

    <div class="card">
            <div class="card-body py-1 px-0 overflow-auto">

                <form class="mb-3">

                    <div class="filters px-0">
                        
                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Rechercher</label>
                                <input type="text" placeholder="Rechercher" class="form-control" wire:model="search" wire:keyup="search_function" />
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Thématique</label>
                                <select class="form-control" wire:model="thematique" wire:change="search_function">
                                    <option value="">Tous</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $thematiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thematique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($thematique->id); ?>"><?php echo e($thematique->thematique); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Ville</label>
                                <select class="form-control" wire:model="ville" wire:change="search_function">
                                    <option value="">Tous</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ville->id); ?>"><?php echo e($ville->ville); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Département</label>
                                <select class="form-control" wire:model="departement" wire:change="search_function">
                                    <option value="">Tous</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $departements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($departement->id); ?>"><?php echo e($departement->departement); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Publié</label>
                                <select class="form-control" wire:model="publier" wire:change="search_function">
                                    <option value="" selected>Tous</option>
                                    <option value="oui">Oui</option>
                                    <option value="non">Non</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Acheté</label>
                                <select class="form-control" wire:model="payer" wire:change="search_function">
                                    <option value="" selected>Tous</option>
                                    <option value="oui">Oui</option>
                                    <option value="non">Non</option>
                                </select>
                            </div>
                        </div>

                    </div>

                </form>

                        <table class="custom-table w-100">
                            <thead>
                                <th>Référence</th>
                                <th>Nom Prénom</th>
                                <th>Tel</th>
                                <th>Thématique</th>
                                <th>Département</th>
                                <th>Code Postale</th>
                                <th>Publier</th>
                                <!--[if BLOCK]><![endif]--><?php if(session("auth")["role"] == "superviseur"): ?>
                                    <th>Acheter</th>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <th>Action</th>
                            </thead>
                            <tbody class="custom-striped">
                            
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($lead->reference); ?></td>
                                    <td><?php echo e($lead->prospect->nom); ?> <?php echo e($lead->prospect->prenom); ?></td>
                                    <td><?php echo e($lead->prospect->tel); ?></td>
                                    <td><?php echo e(optional($lead->thematique)->thematique); ?></td>
                                    <td><?php echo e(optional($lead->departement)->departement); ?></td>
                                    <td><?php echo e($lead->code_postale); ?></td>
                                    <td>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" wire:click="activation(<?php echo e($lead->publier); ?>, <?php echo e($lead->id); ?>)" id="activation<?php echo e($lead->id); ?>" <?php if($lead->publier): ?> checked <?php endif; ?>>
                                            <label class="custom-control-label" for="activation<?php echo e($lead->id); ?>"></label>
                                        </div>
                                    </td>
                                    <!--[if BLOCK]><![endif]--><?php if(session("auth")["role"] == "superviseur"): ?>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($lead->payer == 1): ?>
                                            <span class="badge badge-success px-1">Oui</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger px-1">Non</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <td>
                                        <a href="<?php echo e(route('admin.lead-modifier', $lead->id )); ?>" title="Modifier" wire:navigate>
                                            <i class="fa-solid fa-pen-clip fa-lg text-secondary mr-1"></i>
                                        </a>
                                        <a href="#" title="Supprimer" wire:click="delete_Lead(<?php echo e($lead->id); ?>)">
                                            <i class="fa-solid fa-trash-can fa-lg text-danger"></i>
                                        </a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                            </tbody>
                        </table>

                    <!-- Pagination Links -->
                    <div class="d-flex justify-content-end mt-2 mx-2">
                            <?php echo e($leads->links('pagination::bootstrap-4')); ?>

                    </div>

                </div>

            </div>
</div><?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app-2\resources\views/livewire/admin/lead/index.blade.php ENDPATH**/ ?>