<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="margin: 0; padding: 0; background-color: #eee7e7;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td align="center" style="padding: 30px;">
                <table width="500" cellpadding="0" cellspacing="0" border="0" style="background-color: white; box-shadow: 1px 1px 10px 2px rgba(0,0,0, 0.03);">
                    <tr>
                        <td align="center" style="padding: 10px 0;">
                            <img width="188" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiVsdUAMjNIfdBAEFsWQvqMlJhcp7prM1ypSBnbjJhz9_B6re6wlMP1KFhDj5bnQ0UirqaS_jfcAJ_becmhssh52iwflABraf4gEyvfLA2qESkQYW7seOHmdV45aRQBJ4_FXNm2lRJQgMsWhO3EWNeYNohPZwhUzC1JNqbJSd1_OcSKeK4Wi8uuuE7xvBuI/s16000/logo.png" />
                        </td>
                    </tr>
                    <tr>
                        <td align="center" style="padding: 10px;">
                            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhy7muZDpeG-BXfVWoSjl2r6ud3WdwF4gmHbuqqQW1xNkSzMaEjZt-HkIcldCCr0ajlI-LRFyjh21wvD_JwCplLfnSl2JytyvnZPMWDA3mm5RbLa7HITvS-2ZEJDhjcX5UWZip8Yo7XxEy3MYs91B6poh_F_w4etT9vzTgy17S_yS-cI80nYraeQ5IpE__H/s16000/city.png" />
                        </td>
                    </tr>
                    <tr>
                        <td align="center" style="font-size: 24px; font-weight: bold; padding: 20px;">Salut Alice</td>
                    </tr>
                    <tr>
                        <td align="center" style="font-size: 16px; color: rgb(38, 38, 38); line-height: 1.5; padding: 0 20px; margin-bottom: 30px;">
                            Bienvenue sur Lead & Boost! Nous sommes ravis de vous avoir avec nous, Notre équipe vérifiera vos informations via un appel téléphonique qui vous sera effectué dans les prochaines heures.
                        </td>
                    </tr>
                    <tr>
                        <td align="center" style="padding: 20px;">
                            <div style="background-color: #ED2027; color: white; font-weight: bold; text-align: center; line-height: 45px; height: 45px; border-radius: 5px;">
                                <a href="#" style="color: white; text-decoration: none;">Accéder au Marketplace</a>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" style="font-size: 17px; color: rgb(38, 38, 38); padding: 10px;">Retrouvez nous sur</td>
                    </tr>
                    <tr>
                        <td align="center" style="padding: 10px;">
                            <a href="https://www.facebook.com/" target="_blank" style="font-size: 14px; color: rgb(0, 105, 196); text-decoration: none; margin-right: 20px;">Facebook</a>
                            <a href="https://www.linkedin.com/" target="_blank" style="font-size: 14px; color: rgb(0, 105, 196); text-decoration: none; margin-right: 20px;">LinkedIn</a>
                            <a href="https://www.youtube.com/" target="_blank" style="font-size: 14px; color: rgb(0, 105, 196); text-decoration: none;">Youtube</a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH D:\leads-app\resources\views/mail/testMail.blade.php ENDPATH**/ ?>