<div>

    <?php $__env->startSection("title"); ?>
        Ajouter un Coupon
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
        Ajouter un Coupon
    <?php $__env->stopSection(); ?>

    <div class="row">

        <div class="col-4"> 
 
            <div class="card mb-3">
                <div class="card-body py-2 px-2 overflow-visitble">

                    <div class="search-container">

                        <div class="form-group mb-0">
                            <label for="search-client">Recherche de client</label>
                            <input type="text" class="form-control" id="search-client" placeholder="Rechercher" autocomplete="off" wire:keyup="client_search" wire:model="client">
                            <!--[if BLOCK]><![endif]--><?php if(sizeof($client_search_result) > 0): ?>
                                <div class="search-result">
                                    <ul>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $client_search_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="#" class="lead" wire:click="add_client(<?php echo e($client->id); ?>)">
                                                    <span class="mr-1"><?php echo e($client->entreprise); ?></span><span><?php echo e($client->nom); ?> <?php echo e($client->prenom); ?></span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </ul>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <span class="error"></span>
                        </div>

                    </div>

                </div>
            </div>

        </div>



        <div class="col-4"> 
            <div class="card mb-3">
                <div class="card-body py-2 px-2 overflow-visitble">
                    <div class="row">
                        <div class="col-8">
                            <div class="form-group mb-0">
                                <label>Coupon Code</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['coupon_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="coupon-code" autocomplete="off" wire:model="coupon_code">
                                <span class="error">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['coupon_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </span>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group mb-0">
                                <label for="reduction">Réduction</label>
                                <input type="text" class="form-control text-center <?php $__errorArgs = ['coupon_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="reduction" autocomplete="off" wire:model="coupon_discount">
                                <span class="error">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['coupon_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="col-4"> 
 
            <div class="card mb-3">
                <div class="card-body py-2 px-2 overflow-visitble">
                    <div class="row">
                    <div class="col-6">
                        <div class="form-group mb-0">
                            <label>Date Debut</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['date_debut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="date_debut">
                            <span class="error"></span>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group mb-0">
                            <label>Date Fin</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['date_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="date_fin">
                            <span class="error"></span>
                        </div>
                    </div>
                    </div>
                </div>
            </div>

        </div>


        <div class="col-12">

            <div class="w-100 mb-3">

            <div class="d-flex justify-content-between align-items-center mb-1">
                <h3 class="fw-bold">CLIENTS (<?php echo e(sizeof($client_ids)); ?>)</h3>
                <button class="custom-btn" wire:click="ajouter">Ajouter</button>
            </div>


                <div class="card">
                    <div class="card-body py-1 px-0 overflow-auto" style="max-height:300px">

                        <table class="custom-table w-100">
                            <thead>
                                <th>Entreprise</th>
                                <th>Nom Prénom</th>
                                <th>Tel</th>
                                <th>Email</th>
                                <th>N° Identification</th>
                                <th>Siren</th>
                                <th>Siret</th>
                                <th>RCS</th>
                                <th>Supprimer</th>
                            </thead>
                            <tbody class="custom-striped">

                                <!--[if BLOCK]><![endif]--><?php if(sizeof($selected_clients) == 0): ?>
                                    <tr>
                                        <td colspan="9">
                                            <div class="h5 mb-0">Aucun client sélectionné</div>
                                        </td>
                                    </tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selected_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client->entreprise); ?></td>
                                        <td><?php echo e($client->nom); ?> <?php echo e($client->prenom); ?></td>
                                        <td><?php echo e($client->tel); ?></td>
                                        <td><?php echo e($client->email); ?></td>
                                        <td><?php echo e($client->numero_identification); ?></td>
                                        <td><?php echo e($client->siren); ?></td>
                                        <td><?php echo e($client->siret); ?></td>
                                        <td><?php echo e($client->rcs); ?></td>
                                        <td>
                                            <a href="#" title="Supprimer" wire:click="delete_client(<?php echo e($client->id); ?>, <?php echo e($index); ?>)">
                                                <i class="fa-solid fa-trash-can fa-lg text-danger"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>

        </div>

    </div>


    <!----- Modal ------->
    <div class="modal fade" id="coupon-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center">RÉDUCTION</h5>
            </div>
            <div class="modal-body pt-2 pb-4 text-center">
                <div class="h1" style="font-size:35px"><?php echo e($coupon_discount); ?>% OFF</div>
                <div class="coupon-box d-flex justify-content-between align-items-center">
                    <i class="fa-solid fa-scissors" style="font-size:40px"></i>
                    <div class="h2"><?php echo e($coupon_code); ?></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
            </div>
            </div>
        </div>
    </div>
    <!------ End Modal ----->

</div>
<?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app-2\resources\views/livewire/admin/coupon-ajouter/index.blade.php ENDPATH**/ ?>