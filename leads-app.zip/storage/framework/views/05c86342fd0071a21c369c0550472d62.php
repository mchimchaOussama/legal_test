<div>

    <?php $__env->startSection("title"); ?>
        Coupons
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
        COUPONS
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("element"); ?>
        <a role="button" class="btn btn-primary" href="<?php echo e(route('admin.coupon-ajouter')); ?>" wire:navigate>Ajouter un Coupon</a>
    <?php $__env->stopSection(); ?>

    <div class="card">
        <div class="card-body py-1 px-0 overflow-auto">

            <table class="custom-table w-100">
                <thead>
                    <th>Coupon</th>
                    <th>Réduction</th>
                    <th>Clients</th>
                    <th>Département</th>
                    <th>Prix</th>
                    <th>Action</th>
                </thead>

                <tbody class="custom-striped">
                
                    <!--[if BLOCK]><![endif]--><?php if($coupons->count() == 0): ?>
                        <tr>
                            <td colspan="6">Aucun coupon</td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($coupon->coupon); ?></td>
                        <td><?php echo e($coupon->reduction); ?> %</td>
                        <td><?php echo e($coupon->clients->count()); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        
        </div>
    </div>


</div>
<?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app-2\resources\views/livewire/admin/coupon/index.blade.php ENDPATH**/ ?>