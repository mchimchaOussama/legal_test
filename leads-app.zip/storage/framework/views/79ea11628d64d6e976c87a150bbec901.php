<div>

    <?php $__env->startSection("title"); ?>
    Détails de Client
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
    DÉTAILS DE Client
    <?php $__env->stopSection(); ?>


        <div class="row">
            <div class="col-md-12 col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Client</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group mb-1">
                                    <label>Entreprise</label>
                                    <input type="text" class="form-control "  wire:model="entreprise" readonly />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-1">
                                    <label>Numero Identification</label>
                                    <input type="text" class="form-control "  wire:model="numero_identification" readonly />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-1">
                                    <label>Nom & Prenom</label>
                                    <input type="text" class="form-control "  wire:model="nomPrenom_client" readonly />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group mb-1">
                                    <label>Siren</label>
                                    <input type="text" class="form-control  "  wire:model="siren" readonly />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-1">
                                    <label>Siret</label>
                                    <input type="text" class="form-control "  wire:model="siret" readonly />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-1">
                                    <label>Rcs</label>
                                    <input type="text" class="form-control "  wire:model="rcs" readonly />
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-4">
                                <div class="form-group mb-1">
                                    <label>Tel</label>
                                    <input type="text" class="form-control "  wire:model="tel_client" readonly />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-1">
                                    <label>Email</label>
                                    <input type="text" class="form-control "  wire:model="email_client" readonly />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="col-md-4 col-12">
                <div class="card" style="height:300px;overflow-y:auto">
                    <div class="card-body  hidden-scroll w-100 px-0" style="height:165px;overflow-y:auto">
                        <table class="custom-table w-100">
                            <thead>
                                <th>Thématique</th>
                            </thead>
                            <tbody class="custom-striped">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $thematiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thematique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($thematique->thematique); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-12">
                <div class="card" style="height:300px;overflow-y:auto">
                    <div class="card-body  hidden-scroll w-100 px-0" style="height:165px;overflow-y:auto">
                        <table class="custom-table w-100">
                            <thead>
                                <th>N°</th>
                                <th>Département</th>
                            </thead>
                            <tbody class="custom-striped">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $departements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($departement->num); ?></td>
                                    <td><?php echo e($departement->departement); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-12">
                <div class="card" style="height:300px;overflow-y:auto">
                    <div class="card-body  hidden-scroll w-100 px-0" style="height:165px;overflow-y:auto">
                        <table class="custom-table w-100">
                            <thead>
                                <th>Code postale</th>
                                <th>Ville</th>
                            </thead>
                            <tbody class="custom-striped">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ville->code_postale_id); ?></td>
                                    <td><?php echo e($ville->ville); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>







            <div class="col-md-12 col-12">

            <div class="h2 fw-bold mb-1">ACHATS</div>

                <div class="card" style="max-height:300px;overflow-y:auto;">
                    <div class="card-body">
                        <div class="row">
                        <table class="custom-table w-100">
                                <thead>
                                    <th>Prospect</th>
                                    <th>Thématique</th>
                                    <th>Mode Consommation</th>
                                    <th>Département</th>
                                    <th>Methode</th>
                                    <th>Prix</th>
                                    <th>Action</th>
                                </thead>
                                <tbody class="custom-striped">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($payment->prospect->nom); ?> <?php echo e($payment->prospect->prenom); ?> </td>
                                        <td><?php echo e($payment->thematique->thematique); ?></td>
                                        <td><?php echo e($payment->lead->modeConsommation); ?></td>
                                        <td><?php echo e($payment->departement->departement); ?></td>
                                        <td><?php echo e($payment->methode); ?></td>
                                        <td><?php echo e($payment->prix); ?></td>
                                        <td>                                                    
                                                <a href="<?php echo e(route('admin.payment.show', $payment->id )); ?>" title="Show" wire:navigate>
                                                <i class="fa-solid fa-file-lines fa-lg"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                            <div class="d-flex  mt-1 mx-4">
                                <div class="btn-group" role="group">
                                    <?php echo e($payments->links('pagination::bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div><?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app-2\resources\views/livewire/admin/client/show/index.blade.php ENDPATH**/ ?>