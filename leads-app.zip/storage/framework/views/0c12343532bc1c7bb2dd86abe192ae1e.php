 
<?php $__env->startSection('title', 'Marketplace'); ?> 
<?php $__env->startSection('content'); ?>






<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">


<!-- Mirrored from themesflat.co/html/homzen/sidebar-grid.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 14 Oct 2024 22:35:00 GMT -->


<body class="body">

    <div class="preload preload-container">
        <div class="boxes ">
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
        </div>
    </div>
    
    <!-- /preload -->

    <div id="wrapper">
        <div id="pagee" class="clearfix">
            <!-- Main Header -->
            <header class="main-header fixed-header">
                <!-- Header Lower -->
                <div class="header-lower">
                    <div class="row">                      
                        <div class="col-lg-12">         
                            <div class="inner-container d-flex justify-content-between align-items-center">
                                <!-- Logo Box -->
                                <div class="logo-box">
                          <!--<div class="logo"><a href="index.html"><img src="images/logo/logo%402x.png" alt="logo" width="174" height="44"></a></div> -->   
                                    <a class="navbar-brand ms-5" href="index.html">
                                        <img src="<?php echo e(asset('assetsMarketplace/images/logo.png')); ?>"  width="174" height="44" alt="logo"  />
                                    </a>
                                </div>
                                <div class="nav-outer">
                                    <!-- Main Menu -->
                                    <nav class="main-menu show navbar-expand-md">
                                        <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                                            <ul class="navigation clearfix">
                                                <li class=" home "><a href="<?php echo e(route('get.home')); ?>">Accueil</a>
                                                </li>

                                                <li class="dropdown2"><a href="#">Thematique</a>
                                                    <ul>
                                                        <?php $__currentLoopData = $thematiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thematique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a href="<?php echo e(route('get.marketplace')); ?>"><?php echo e($thematique->thematique); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </li>

                                                <li class="current"><a href="<?php echo e(route('get.marketplace')); ?>">Marketplace</a>
                                                </li>

                                                <li class=""><a href="#">A Propos</a>
                                                </li>


                                                <li class=""><a href="<?php echo e(route('get.faq')); ?>">FAQ</a>
                                                </li>
                        
                                                <?php if(session()->has('client_hom')): ?>

                                                <li class="dropdown2"><a href="#">Bienvenue, <?php echo e(session('client_hom')->nom); ?></a>
                                                    <ul>
                                                        <li><a href="dashboard.html">Dashboard</a></li>
                                                        <li><a href="my-favorites.html">My Properties</a></li>
                                                        <li><a href="my-invoices.html">My Invoices</a></li>
                                                        <li><a href="my-favorites.html">My Favorites</a></li>
                                                        <li><a href="reviews.html">Reviews</a></li>
                                                        <li><a href="my-profile.html">My Profile</a></li>
                                                        <li><a href="add-property.html">Add Property</a></li>
                                                        <li> 
                                                        <a href="#">
                                                        <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" style="border: none; background: none;  cursor: pointer;">
                                                                déconnecter
                                                            </button>
                                                        </form>
                                                        </a>

                                                        </li>
                                                    </ul>
                                                </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </nav>
                                    <!-- Main Menu End-->
                                </div>
                                <div class="header-account">
                                    <div class="register">
                                        <ul class="d-flex">
                                        <?php if(session()->has('client_hom')): ?>
                                            
                                            <?php else: ?>
                                                <li><a href="#modalLogin" data-bs-toggle="modal">Login</a></li>
                                                <li>/</li>
                                                <li><a href="#modalRegister" data-bs-toggle="modal">Register</a></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <!--
                                    <div class="flat-bt-top">
                                        <a class="tf-btn primary" href="add-property.html">Submit Property</a>
                                    </div>  
                                    -->
                                </div>
                                
                                <div class="mobile-nav-toggler mobile-button"><span></span></div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Header Lower -->

            
                <!-- Mobile Menu  -->
                <div class="close-btn"><span class="icon flaticon-cancel-1"></span></div>    
                <div class="mobile-menu">
                    <div class="menu-backdrop"></div>                            
                    <nav class="menu-box">
                        <div class="nav-logo"><a href="index.html"><img src="<?php echo e(asset('assetsMarketplace/images/logo/logo%402x.png')); ?>" alt="nav-logo" width="174" height="44"></a></div>
                        
                        <div class="bottom-canvas">
                            <div class="login-box flex align-items-center">
                                <a href="#modalLogin" data-bs-toggle="modal">Login</a>
                                <span>/</span>
                                <a href="#modalRegister" data-bs-toggle="modal">Register</a>
                            </div>
                            <div class="menu-outer"></div>
                            <div class="button-mobi-sell">
                                <a class="tf-btn primary" href="add-property.html">Submit Property</a>
                            </div> 
                            <div class="mobi-icon-box">
                                <div class="box d-flex align-items-center">
                                    <span class="icon icon-phone2"></span>
                                    <div>1-333-345-6868</div>
                                </div>
                                <div class="box d-flex align-items-center">
                                    <span class="icon icon-mail"></span>
                                    <div>themesflat@gmail.com</div>
                                </div>
                            </div>
                        </div>
                    </nav>                
                </div>
                <!-- End Mobile Menu -->
            
            </header>

            <section class="flat-section flat-benefit bg-surface">
                <div class="container">
                    <div class="box-title text-center wow fadeInUpSmall" data-wow-delay=".2s" data-wow-duration="2000ms">
                        <div class="text-subtitle text-primary">La place de marché 100% Lead !</div>
                        <h4 class="mt-4">Filtrer par département, par thématique, et choisissez !</h4>
                    </div>
                    <div class="wrap-benefit wow fadeInUpSmall" data-wow-delay=".2s" data-wow-duration="2000ms">
                        <div class="box-benefit">
                            <div class="icon-box">
                                <span class="icon icon-proven"></span>
                            </div>
                            <div class="content text-center">
                                <h6 class="title">Nos Leads sont tous exclusifs</h6>
                                <p class="description">Nous garantissons un lead 100% exclusif pour une meilleure transformation .</p>
                            </div>
                        </div>
                        <div class="box-benefit">
                            <div class="icon-box">
                                <span class="icon icon-double-ruler"></span>
                            </div>
                            <div class="content text-center">
                                <h6 class="title">100% des LEAD Vérifiés !</h6>
                                <p class="description">Chaque LEAD présent sur la plate-forme ont été appelé par un expert pour verifier l'exactitude des informations</p>
                            </div>
                        </div>
                        <div class="box-benefit">
                            <div class="icon-box">
                                <span class="icon icon-hand"></span>
                            </div>
                            <div class="content text-center">
                                <h6 class="title">100% fiable</h6>
                                <p class="description">En cas de manquement, faux numéros, mauvais email , sous 48h votre lead est remplacé</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- End Main Header -->
  
            <section class="flat-section-v6 flat-recommended flat-sidebar">
                <div class="container">
                    <div class="box-title-listing">
                        <h5 class='text-decoration-underline' >Marketplace</h5>
                        <div class="box-filter-tab">
                            <ul class="nav-tab-filter" role="tablist">
                                <li class="nav-tab-item" role="presentation">   
                                    <a href="#gridLayout" class="nav-link-item active" data-bs-toggle="tab"><i class="icon icon-grid"></i></a>
                                </li>
                                <li class="nav-tab-item" role="presentation">
                                    <a href="#listLayout" class="nav-link-item" data-bs-toggle="tab"><i class="icon icon-list"></i></a>
                                </li>
                            </ul>
                            <!--
                            <div class="nice-select list-page" tabindex="0"><span class="current">12 Per Page</span>
                                <ul class="list">  
                                    <li data-value="1" class="option">10 Per Page</li>                                                        
                                    <li data-value="2" class="option">11 Per Page</li>
                                    <li data-value="3" class="option selected">12 Per Page</li>
                                </ul>
                            </div>
                            <div class="nice-select list-sort" tabindex="0"><span class="current">Sort by (Default)</span>
                                <ul class="list">  
                                    <li data-value="default" class="option selected">Sort by (Default)</li>                                                        
                                    <li data-value="new" class="option">Newest</li>
                                    <li data-value="old" class="option">Oldest</li>
                                </ul>
                            </div>
                            -->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-4 col-lg-5">
                            <div class="widget-sidebar fixed-sidebar">
                                <div class="flat-tab flat-tab-form widget-filter-search widget-box bg-surface">
                                    <div class="h7 title fw-7"></div>
                                    <ul class="nav-tab-form" role="tablist">
                                        <li class="nav-tab-item" role="presentation">   
                                            <a href="#forRent" class="nav-link-item "  data-bs-toggle="tab">Filtrer</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane fade active show" role="tabpanel">
                                            <div class="form-sl">
                                            <form method="POST" action="<?php echo e(route('post.marketplace')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="wd-filter-select">
                                                    <div class="inner-group inner-filter">
                                                        <div class="form-style">
                                                            <label>Thematique</label>
                                                            <div class="group-select">
                                                                <select class='form-select no-border' name="thematique_id">
                                                                    <option value=''>Tout</option>
                                                                    <?php $__currentLoopData = $thematiquesFurstSlideSherchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thematiquesFurstSlideSherch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($thematiquesFurstSlideSherch->id); ?>" 
                                                                            <?php echo e(session('thematique_id') == $thematiquesFurstSlideSherch->id ? 'selected' : ''); ?>>
                                                                            <?php echo e($thematiquesFurstSlideSherch->thematique); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                                                </select>
                                                            </div>                                                    
                                                        </div>

                                                        <div class="form-style">
                                                            <label>Departement</label>
                                                            <div class="group-select">
                                                                <select class='form-select no-border' name="departement_id">
                                                                    <option value=''>Tout</option>
                                                                    <?php $__currentLoopData = $DepartementFurstSlideSherchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $DepartementFurstSlideSherch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($DepartementFurstSlideSherch->id); ?>" 
                                                                            <?php echo e(session('departement_id') == $DepartementFurstSlideSherch->id ? 'selected' : ''); ?>>
                                                                            <?php echo e($DepartementFurstSlideSherch->departement); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                                                </select>                                               
                                                            </div>                                                    
                                                        </div>

                                                        <div class="form-style">
                                                            <label>Type</label>
                                                            <div class="group-select">
                                                                <select class='form-select no-border' name="type">
                                                                    <option value=''>Tout</option>
                                                                    <option value="B2B" <?php echo e(session('type') == 'B2B' ? 'selected' : ''); ?>>B2B</option>
                                                                    <option value="B2C" <?php echo e(session('type') == 'B2C' ? 'selected' : ''); ?>>B2C</option>
                                                                </select>                                               
                                                            </div>  
                                                        </div>

                                                        <div class="form-style">
                                                            <label>Date Debut</label>
                                                            <input type="date" name="date_debut" class='form-input' value="<?php echo e(session('date_debut')); ?>">                                             
                                                        </div>

                                                        <div class="form-style">
                                                            <label>Date Fin</label>
                                                            <input type="date" name="date_fin" class='form-input' value="<?php echo e(session('date_fin')); ?>">                                             
                                                        </div>

                                                        <div class="form-style">
                                                            <button type="submit" class="tf-btn primary">Recherche</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                                <!--
                                <div class="widget-box bg-surface box-latest-property">
                                    <div class="h7 fw-7 title">Latest Propeties</div>
                                    <ul>
                                        <li class="latest-property-item">
                                            <a href="property-details-v1.html" class="images-style">
                                                <img src="images/home/house-sm-3.jpg" alt="img">
                                            </a>
                                            <div class="content">
                                                <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Casa Lomas de Mach...</a></div>
                                                <ul class="meta-list">
                                                    <li class="item">
                                                        <span>Bed:</span>
                                                        <span class="fw-7">4</span>
                                                    </li>
                                                    <li class="item">
                                                        <span>Bath:</span>
                                                        <span class="fw-7">2</span>
                                                    </li>
                                                    <li class="item">
                                                        <span class="fw-7">600 SqFT</span>
                                                    </li>
                                                </ul>
                                                <div class="d-flex align-items-center">
                                                    <div class="h7 fw-7">$5050,00</div>
                                                    <span class="text-variant-1">/SqFT</span>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="latest-property-item">
                                            <a href="property-details-v1.html" class="images-style">
                                                <img src="images/home/house-sm-9.jpg" alt="img">
                                            </a>
                                            <div class="content">
                                                <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Lakeview Haven...</a></div>
                                                <ul class="meta-list">
                                                    <li class="item">
                                                        <span>Bed:</span>
                                                        <span class="fw-7">4</span>
                                                    </li>
                                                    <li class="item">
                                                        <span>Bath:</span>
                                                        <span class="fw-7">2</span>
                                                    </li>
                                                    <li class="item">
                                                        <span class="fw-7">600 SqFT</span>
                                                    </li>
                                                </ul>
                                                <div class="d-flex align-items-center">
                                                    <div class="h7 fw-7">$5050,00</div>
                                                    <span class="text-variant-1">/SqFT</span>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="latest-property-item">
                                            <a href="property-details-v1.html" class="images-style">
                                                <img src="images/home/house-sm-1.jpg" alt="img">
                                            </a>
                                            <div class="content">
                                                <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Sunset Heights Estate</a></div>
                                                <ul class="meta-list">
                                                    <li class="item">
                                                        <span>Bed:</span>
                                                        <span class="fw-7">4</span>
                                                    </li>
                                                    <li class="item">
                                                        <span>Bath:</span>
                                                        <span class="fw-7">2</span>
                                                    </li>
                                                    <li class="item">
                                                        <span class="fw-7">600 SqFT</span>
                                                    </li>
                                                </ul>
                                                <div class="d-flex align-items-center">
                                                    <div class="h7 fw-7">$5050,00</div>
                                                    <span class="text-variant-1">/SqFT</span>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="latest-property-item">
                                            <a href="property-details-v1.html" class="images-style">
                                                <img src="images/home/house-sm-4.jpg" alt="img">
                                            </a>
                                            <div class="content">
                                                <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">de Machalí Machas...</a></div>
                                                <ul class="meta-list">
                                                    <li class="item">
                                                        <span>Bed:</span>
                                                        <span class="fw-7">4</span>
                                                    </li>
                                                    <li class="item">
                                                        <span>Bath:</span>
                                                        <span class="fw-7">2</span>
                                                    </li>
                                                    <li class="item">
                                                        <span class="fw-7">600 SqFT</span>
                                                    </li>
                                                </ul>
                                                <div class="d-flex align-items-center">
                                                    <div class="h7 fw-7">$5050,00</div>
                                                    <span class="text-variant-1">/SqFT</span>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                    
                                    
                                </div>
                                -->
                            </div>
                            
                        </div>
                        <div class="col-xl-8 col-lg-7">
                            <div class="tab-content">
                                <div class="tab-pane fade active show" id="gridLayout" role="tabpanel">
                                    <div class="row">
                                                <?php $__currentLoopData = $leadAlls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leadAll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                        <div class="col-md-4">
                                            <div class="homeya-box">
                                                <div class="archive-top">
                                                    <a href="<?php echo e(route('get.detai', $leadAll->id)); ?>" class="images-group">
                                                        <div class="images-style">
                                                        <img src="<?php echo e(asset('storage/' . $leadAll->thematique->image)); ?>" alt="img" style="width: 260px; height: 182px;" />
                                                        </div>
                                                        <div class="top">
                                                        <li class=""><span class='flag-tag style-2'><?php echo e($leadAll->departement->departement); ?> </span> <span class='flag-tag style-2'><?php echo e($leadAll->code_postale); ?></span></li>
                                                            <ul class="d-flex gap-4">
                                                                <!--
                                                                <li class="box-icon w-32">
                                                                  <span class="icon icon-eye"></span>
                                                                </li>
                                                                 -->
                                                            </ul>
                                                        </div>
                                                        <div class="bottom">
                                                            <span class="flag-tag success style-2"><?php echo e($leadAll->thematique->thematique); ?></span>
                                                        </div>
                                                    </a>
                                                    <div class="content">
                                                        <div class='row'>
                                                            <div class="col-lg-9">  <div class="text-capitalize fw-7">
                                                                <a href="<?php echo e(route('get.detai', $leadAll->id)); ?>" class="link" alt='<?php echo e($leadAll->modeConsommation); ?>'>
                                                                    <?php
                                                                        $words = explode(' ', $leadAll->modeConsommation); // Split the string into an array of words
                                                                    ?>

                                                                    <?php if(count($words) > 2): ?>
                                                                        <?php echo e(implode(' ', array_slice($words, 0, 2)) . '...'); ?> 
                                                                    <?php else: ?>
                                                                        <?php echo e($leadAll->modeConsommation); ?>

                                                                    <?php endif; ?>
                                                                </a>
                                                            </div>
                                                        </div>
                                                            <div class="col-lg-3"><span> <i class="fas fa-eye"></i><span><?php echo e($leadAll->viewed_by_clients_count); ?></span> </span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="archive-bottom d-flex justify-content-between align-items-center">
                                                    <div class="d-flex gap-8 align-items-center">
                                                    <p class='h7'>€ <?php echo e($leadAll->prix); ?></p> 
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                    <li><button class="btn btn-primary btn-sm"> <i class="fas fa-shopping-cart"></i> </button></li>               
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <ul class="wd-navigation">
                                    <?php echo e($leadAlls->links('pagination::bootstrap-4')); ?>

                                    </ul>
                                </div>
                                <div class="tab-pane fade" id="listLayout" role="tabpanel">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="homeya-box list-style-1 list-style-2">
                                                <a href="property-details-v1.html" class="images-group">
                                                    <div class="images-style">
                                                        <img src="images/home/house-9.jpg" alt="img">
                                                    </div>
                                                    <div class="top">
                                                        <ul class="d-flex gap-4 flex-wrap">
                                                            <li class="flag-tag style-1">For Sale</li>
                                                        </ul>
                                                        <ul class="d-flex gap-4">
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-arrLeftRight"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-heart"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-eye"></span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="bottom">
                                                        <span class="flag-tag style-2">Villa</span>
                                                    </div>
                                                </a>
                                                <div class="content">
                                                    <div class="archive-top">
                                                        <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Casa Lomas de Machalí Machas</a></div>
                                                        <div class="desc"><i class="icon icon-mapPin"></i><p>145 Brooklyn Ave, Califonia, New York</p> </div>
                                                        <ul class="meta-list">
                                                            <li class="item">
                                                                <i class="icon icon-bed"></i>
                                                                <span>4</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-bathtub"></i>
                                                                <span>2</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-ruler"></i>
                                                                <span>600 SqFT</span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center archive-bottom">
                                                        <div class="d-flex gap-8 align-items-center">
                                                            <div class="avatar avt-40 round">
                                                                <img src="images/avatar/avt-8.jpg" alt="avt">
                                                            </div>
                                                            <span>Jacob Jones</span>
                                                        </div>
                                                        <div class="d-flex align-items-center">
                                                            <div class="h7 fw-7">$5050,00</div>
                                                            <span class="text-variant-1">/SqFT</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="homeya-box list-style-1 list-style-2">
                                                <a href="property-details-v1.html" class="images-group">
                                                    <div class="images-style">
                                                        <img src="images/home/house-10.jpg" alt="img">
                                                    </div>
                                                    <div class="top">
                                                        <ul class="d-flex">
                                                            <li class="flag-tag style-1">For Rent</li>
                                                        </ul>
                                                        <ul class="d-flex gap-4">
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-arrLeftRight"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-heart"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-eye"></span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="bottom">
                                                        <span class="flag-tag style-2">House</span>
                                                    </div>
                                                </a>
                                                <div class="content">
                                                    <div class="archive-top">
                                                        <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Lakeview Haven, Lake Tahoe </a></div>
                                                        <div class="desc"><i class="icon icon-mapPin"></i><p>145 Brooklyn Ave, Califonia, New York</p> </div>
                                                        <ul class="meta-list">
                                                            <li class="item">
                                                                <i class="icon icon-bed"></i>
                                                                <span>4</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-bathtub"></i>
                                                                <span>2</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-ruler"></i>
                                                                <span>600 SqFT</span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center archive-bottom">
                                                        <div class="d-flex gap-8 align-items-center">
                                                            <div class="avatar avt-40 round">
                                                                <img src="images/avatar/avt-10.jpg" alt="avt">
                                                            </div>
                                                            <span>Floyd Miles</span>
                                                        </div>
                                                        <div class="d-flex align-items-center">
                                                            <div class="h7 fw-7">$250,00</div>
                                                            <span class="text-variant-1">/month</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="homeya-box list-style-1 list-style-2">
                                                <a href="property-details-v1.html" class="images-group">
                                                    <div class="images-style">
                                                        <img src="images/home/house-6.jpg" alt="img">
                                                    </div>
                                                    <div class="top">
                                                        <ul class="d-flex">
                                                         
                                                            <li class="flag-tag style-1">For Sale</li>
                                                        </ul>
                                                        <ul class="d-flex gap-4">
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-arrLeftRight"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-heart"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-eye"></span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="bottom">
                                                        <span class="flag-tag style-2">House</span>
                                                    </div>
                                                </a>
                                                <div class="content">
                                                    <div class="archive-top">
                                                        <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Sunset Heights Estate, Beverly Hills</a></div>
                                                        <div class="desc"><i class="icon icon-mapPin"></i><p>145 Brooklyn Ave, Califonia, New York</p> </div>
                                                        <ul class="meta-list">
                                                            <li class="item">
                                                                <i class="icon icon-bed"></i>
                                                                <span>4</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-bathtub"></i>
                                                                <span>2</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-ruler"></i>
                                                                <span>600 SqFT</span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center archive-bottom">
                                                        <div class="d-flex gap-8 align-items-center">
                                                            <div class="avatar avt-40 round">
                                                                <img src="images/avatar/avt-5.jpg" alt="avt">
                                                            </div>
                                                            <span>Ralph Edwards</span>
                                                        </div>
                                                        <div class="d-flex align-items-center">
                                                            <div class="h7 fw-7">$5050,00</div>
                                                            <span class="text-variant-1">/SqFT</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="homeya-box list-style-1 list-style-2">
                                                <a href="property-details-v1.html" class="images-group">
                                                    <div class="images-style">
                                                        <img src="images/home/house-5.jpg" alt="img">
                                                    </div>
                                                    <div class="top">
                                                        <ul class="d-flex">
                                                            <li class="flag-tag style-1">For Rent</li>
                                                        </ul>
                                                        <ul class="d-flex gap-4">
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-arrLeftRight"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-heart"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-eye"></span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="bottom">
                                                        <span class="flag-tag style-2">apartment</span>
                                                    </div>
                                                </a>
                                                <div class="content">
                                                    <div class="archive-top">
                                                        <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Lakeview Haven, Lake Tahoe</a></div>
                                                        <div class="desc"><i class="icon icon-mapPin"></i><p>145 Brooklyn Ave, Califonia, New York</p> </div>
                                                        <ul class="meta-list">
                                                            <li class="item">
                                                                <i class="icon icon-bed"></i>
                                                                <span>4</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-bathtub"></i>
                                                                <span>2</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-ruler"></i>
                                                                <span>600 SqFT</span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center archive-bottom">
                                                        <div class="d-flex gap-8 align-items-center">
                                                            <div class="avatar avt-40 round">
                                                                <img src="images/avatar/avt-9.jpg" alt="avt">
                                                            </div>
                                                            <span>Annette Black</span>
                                                        </div>
                                                        <div class="d-flex align-items-center">
                                                            <div class="h7 fw-7">$250,00</div>
                                                            <span class="text-variant-1">/month</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="homeya-box list-style-1 list-style-2">
                                                <a href="property-details-v1.html" class="images-group">
                                                    <div class="images-style">
                                                        <img src="images/home/house-1.jpg" alt="img">
                                                    </div>
                                                    <div class="top">
                                                        <ul class="d-flex">
                                                         
                                                            <li class="flag-tag style-1">For Rent</li>
                                                        </ul>
                                                        <ul class="d-flex gap-4">
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-arrLeftRight"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-heart"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-eye"></span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="bottom">
                                                        <span class="flag-tag style-2">apartment</span>
                                                    </div>
                                                </a>
                                                <div class="content">
                                                    <div class="archive-top">
                                                        <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Casa Lomas de Machalí Machas</a></div>
                                                        <div class="desc"><i class="icon icon-mapPin"></i><p>145 Brooklyn Ave, Califonia, New York</p> </div>
                                                        <ul class="meta-list">
                                                            <li class="item">
                                                                <i class="icon icon-bed"></i>
                                                                <span>4</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-bathtub"></i>
                                                                <span>2</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-ruler"></i>
                                                                <span>600 SqFT</span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center archive-bottom">
                                                        <div class="d-flex gap-8 align-items-center">
                                                            <div class="avatar avt-40 round">
                                                                <img src="images/avatar/avt-8.jpg" alt="avt">
                                                            </div>
                                                            <span>Jacob Jones</span>
                                                        </div>
                                                        <div class="d-flex align-items-center">
                                                            <div class="h7 fw-7">$5050,00</div>
                                                            <span class="text-variant-1">/SqFT</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="homeya-box list-style-1 list-style-2">
                                                <a href="property-details-v1.html" class="images-group">
                                                    <div class="images-style">
                                                        <img src="images/home/house-13.jpg" alt="img">
                                                    </div>
                                                    <div class="top">
                                                        <ul class="d-flex">
                                                            <li class="flag-tag style-1">For Rent</li>
                                                        </ul>
                                                        <ul class="d-flex gap-4">
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-arrLeftRight"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-heart"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-eye"></span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="bottom">
                                                        <span class="flag-tag style-2">apartment</span>
                                                    </div>
                                                </a>
                                                <div class="content">
                                                    <div class="archive-top">
                                                        <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Lakeview Haven, Lake Tahoe</a></div>
                                                        <div class="desc"><i class="icon icon-mapPin"></i><p>145 Brooklyn Ave, Califonia, New York</p> </div>
                                                        <ul class="meta-list">
                                                            <li class="item">
                                                                <i class="icon icon-bed"></i>
                                                                <span>4</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-bathtub"></i>
                                                                <span>2</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-ruler"></i>
                                                                <span>600 SqFT</span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center archive-bottom">
                                                        <div class="d-flex gap-8 align-items-center">
                                                            <div class="avatar avt-40 round">
                                                                <img src="images/avatar/avt-9.jpg" alt="avt">
                                                            </div>
                                                            <span>Annette Black</span>
                                                        </div>
                                                        <div class="d-flex align-items-center">
                                                            <div class="h7 fw-7">$250,00</div>
                                                            <span class="text-variant-1">/month</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="homeya-box list-style-1 list-style-2">
                                                <a href="property-details-v1.html" class="images-group">
                                                    <div class="images-style">
                                                        <img src="images/home/house-4.jpg" alt="img">
                                                    </div>
                                                    <div class="top">
                                                        <ul class="d-flex">
                                                            <li class="flag-tag style-1">For Rent</li>
                                                        </ul>
                                                        <ul class="d-flex gap-4">
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-arrLeftRight"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-heart"></span>
                                                            </li>
                                                            <li class="box-icon w-32">
                                                                <span class="icon icon-eye"></span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="bottom">
                                                        <span class="flag-tag style-2">House</span>
                                                    </div>
                                                </a>
                                                <div class="content">
                                                    <div class="archive-top">
                                                        <div class="h7 text-capitalize fw-7"><a href="property-details-v1.html" class="link">Lakeview Haven, Lake Tahoe</a></div>
                                                        <div class="desc"><i class="icon icon-mapPin"></i><p>145 Brooklyn Ave, Califonia, New York</p> </div>
                                                        <ul class="meta-list">
                                                            <li class="item">
                                                                <i class="icon icon-bed"></i>
                                                                <span>4</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-bathtub"></i>
                                                                <span>2</span>
                                                            </li>
                                                            <li class="item">
                                                                <i class="icon icon-ruler"></i>
                                                                <span>600 SqFT</span>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center archive-bottom">
                                                        <div class="d-flex gap-8 align-items-center">
                                                            <div class="avatar avt-40 round">
                                                                <img src="images/avatar/avt-9.jpg" alt="avt">
                                                            </div>
                                                            <span>Kathryn Murphy</span>
                                                        </div>
                                                        <div class="d-flex align-items-center">
                                                            <div class="h7 fw-7">$250,00</div>
                                                            <span class="text-variant-1">/month</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <ul class="justify-content-center wd-navigation">
                                        <li><a href="#" class="nav-item active">1</a></li>
                                        <li><a href="#" class="nav-item">2</a></li>
                                        <li><a href="#" class="nav-item">3</a></li>
                                        <li><a href="#" class="nav-item"><i class="icon icon-arr-r"></i></a></li>
                                    </ul>
                                </div>
                            </div> 
                        </div>
                    </div>

                    
                    
                </div>
            </section>

            <!-- footer -->
            <footer class="footer">
                <div class="top-footer">
                  <div class="container">
                    <div class="content-footer-top">
                        <div class="footer-logo">
                          <img src="<?php echo e(asset('assetsMarketplace/images/logo.png')); ?>" alt="logo-footer" width="174" height="44" class="rounded" >
                        </div>

                    </div>
                  </div>
                </div>
                <div class="inner-footer">
                  <div class="container">
                    <div class="row">
                      <div class="col-lg-4 col-md-6">
                        <div class="footer-cl-1">
                          
                          <p class="text-variant-2">Acheter vos leads en direct ! à l'unité !</p>
                          <ul class="mt-12">
                            <li class="mt-12 d-flex align-items-center gap-8">
                                <i class="icon icon-mapPinLine fs-20 text-variant-2"></i>
                                <p class="text-white">101 E 129th St, East Chicago, IN 46312, US</p>
                            </li>
                            <li class="mt-12 d-flex align-items-center gap-8">
                                <i class="icon icon-mail fs-20 text-variant-2"></i>
                                <p class="text-white">themesflat@gmail.com</p>
                            </li>
                          </ul>
                          
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-6 col-6">
                        <div class="footer-cl-2">
                            <div class="fw-7 text-white">Page</div>
                            <ul class="mt-10 navigation-menu-footer">
                                <li> <a href="<?php echo e(route('get.home')); ?>" class="caption-1 text-variant-2">Accueil</a> </li>

                                <li> <a href="#" class="caption-1 text-variant-2">A Propos</a> </li>

                                <li> <a href="<?php echo e(route('get.faq')); ?>" class="caption-1 text-variant-2">FAQ</a> </li>

                                <li> <a href="#" class="caption-1 text-variant-2">Contact</a> </li>

                            </ul>
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-4 col-6">
                        <div class="footer-cl-3">
                            <div class="fw-7 text-white">Top Thematique</div>
                            <ul class="mt-10 navigation-menu-footer">
                                <?php $__currentLoopData = $thematiquesStatistiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thematiquesStatistique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li> <a href="#" class="caption-1 text-variant-2"><?php echo e($thematiquesStatistique->thematique); ?></a> </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </ul>
                        </div>
                      </div>
                      <div class="col-lg-4 col-md-6">
                        <div class="footer-cl-4">
                            <div class="fw-7 text-white">
                                Newsletter
                            </div>
                            <p class="mt-12 text-variant-2">Votre dose hebdomadaire/mensuelle de connaissances et d’inspiration</p>
                            <form class="mt-12" id="subscribe-form" action="#" method="post" accept-charset="utf-8" data-mailchimp="true">
                                <div id="subscribe-content">
                                    <span class="icon-left icon-mail"></span>
                                    <input type="email" name="email-form" id="subscribe-email" placeholder="Votre email address"/>
                                    <button type="button" id="subscribe-button" class="button-subscribe"><i class="icon icon-send"></i></button>
                                </div>
                                <div id="subscribe-msg"></div>
                            </form>
                        </div>
                      </div>
                      
                    </div>
                  </div>
                </div>
                
                <div class="bottom-footer">
                  <div class="container">
                    <div class="content-footer-bottom">
                        <div class="copyright">© 2024 LEAD AND BOOST (Tous droits réservés).</div>
                          <!-- 
                        <ul class="menu-bottom">
                          <li><a href="our-service.html">Terms Of Services</a> </li>

                          <li><a href="pricing.html">Privacy Policy</a> </li>
                          <li><a href="contact.html">Cookie Policy</a> </li>

                        </ul>
                        -->
                    </div>
                  </div>
                </div>
                
            </footer>
            <!-- end footer -->
        </div>
        <!-- /#page -->

    </div>
    
    <!-- go top -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 286.138;"></path>
        </svg>
    </div>
  <!-- popup login -->
  <div class="modal fade" id="modalLogin">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="flat-account bg-surface">
                <h3 class="title text-center">Se connecter</h3>
                <span class="close-modal icon-close2" data-bs-dismiss="modal"></span>
                <form id="loginForm">
                    <?php echo csrf_field(); ?>
                  <fieldset class="box-fieldset">
                     <!--     <label for="name">Email<span>*</span>:</label>-->
                        <input type="text" class="form-contact style-1" placeholder="Remplir votre Email !" name="email" required>
                        <div id="email-error" class="text-danger mt-1" style="display: none;"></div> <!-- Error message for email -->
                    </fieldset>
                    <fieldset class="box-fieldset">
                      <!--  <label for="pass">Mot de passe<span>*</span>:</label>-->
                        <div class="box-password">
                            <input type="password" class="form-contact style-1 password-field" placeholder="Mot de passe" name="password" required>
                            <span class="show-pass">
                                <i class="icon-pass icon-eye"></i>
                                <i class="icon-pass icon-eye-off"></i>
                            </span>
                        </div>
                        <div id="password-error" class="text-danger mt-1" style="display: none;"></div> <!-- Error message for password -->
                    </fieldset>

                    <fieldset class="d-flex align-items-center gap-6">
                    <label for="cb1" class="caption-1 text-variant-1">J'ai lu et j'accepte <span class="fw-5 text-black">Contact du service.</span> and <span class="fw-5 text-black">Contact du service. </span>Politique de Confidentialité  <input type="checkbox" class="style-2" id="cb1" name="termsAccepted"> </label>
                    </fieldset>

                    <button type="submit" class="tf-btn primary w-100">Se connecter</button>
                    <div class="mt-12 text-variant-1 text-center noti">  <a href="#" class="text-black fw-5">Mot de passe oublié ?</a>/<a href="#modalRegister" data-bs-toggle="modal" class="text-black fw-5">S'inscrire.</a> </div>
                </form>
            </div>
        </div> 
    </div>
</div>




    <!-- popup register -->
    <div class="modal fade" id="modalRegister">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="flat-account bg-surface">
                <h3 class="title text-center">S'inscrire</h3>
                <span class="close-modal icon-close2" data-bs-dismiss="modal" id='reload'></span>

                <!-- Success message div -->
                <div id="success-message" class="alert alert-success" style="display: none;"></div>

                <form id="registerForm" action="#">
                    <?php echo csrf_field(); ?> 
                    <fieldset class="box-fieldset">
                        <label for="name">Nom<span>*</span>:</label>
                        <input type="text" class="form-contact style-1" placeholder="Remplir votre Nom !" name="name" required>
                    </fieldset>

                    <fieldset class="box-fieldset">
                        <label for="prenom">Prenom<span>*</span>:</label>
                        <input type="text" class="form-contact style-1" placeholder="Remplir votre Prenom !" name="prenom" required>
                    </fieldset>

                    <fieldset class="box-fieldset">
                        <label for="email">Email address<span>*</span>:</label>
                        <input type="email" class="form-contact style-1" placeholder="Remplir votre Email !" name="email" required>
                    </fieldset>
                    
                    <!-- Telephone input field -->
                    <fieldset class="box-fieldset">
                        <label for="telephone">Téléphone<span>*</span>:</label>
                        <input type="tel" class="form-contact style-1" placeholder="Remplir votre Téléphone !" name="telephone" required>
                    </fieldset>

                    <fieldset class="box-fieldset">
                        <label for="password">Mot de passe<span>*</span>:</label>
                        <div class="box-password">
                            <input type="password" class="form-contact style-1 password-field" placeholder="Mot de passe" name="password" required>
                            <span class="show-pass">
                                <i class="icon-pass icon-eye"></i>
                                <i class="icon-pass icon-eye-off"></i>
                            </span>
                        </div>
                    </fieldset>
                    
                    <fieldset class="box-fieldset">
                        <label for="confirm_password">Confirmer Mot de passe<span>*</span>:</label>
                        <div class="box-password">
                            <input type="password" class="form-contact style-1 password-field2" placeholder="Confirmer Mot de passe" name="password_confirmation" required>
                            <span class="show-pass2">
                                <i class="icon-pass icon-eye"></i>
                                <i class="icon-pass icon-eye-off"></i>
                            </span>
                        </div>
                    </fieldset>
                    
                    <fieldset class="d-flex align-items-center gap-6">
                    <label for="cb1" class="caption-1 text-variant-1">J'accepte les <span class="fw-5 text-black">Conditions d'Utilisation.</span></label>
                        <input type="checkbox" class="tf-checkbox style-2" id="cb1" name="termsAccepted">
                    </fieldset>

                    
                    <button type="submit" class="tf-btn primary w-100">S'inscrire</button>
                    <div class="mt-12 text-variant-1 text-center noti">Vous avez déjà un compte ?<a href="#modalLogin" data-bs-toggle="modal" class="text-black fw-5">Connectez-vous ici.</a></div>
                </form>
            </div>
        </div> 
    </div>
</div>
<script src="<?php echo e(asset('assetsMarketplace/js/my-js/auth.js')); ?>"></script>
</body>


<!-- Mirrored from themesflat.co/html/homzen/sidebar-grid.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 14 Oct 2024 22:35:00 GMT -->
</html>



















<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.app_client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app\resources\views/Marketplace/marketplace.blade.php ENDPATH**/ ?>