<div>

    <?php $__env->startSection("title"); ?>
        Clients
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
        Clients
    <?php $__env->stopSection(); ?>

    <div class="card">
            <div class="card-body py-1 px-0 overflow-auto">

                <form class="mb-3">

                    <div class="filters px-0">
                        
                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Rechercher</label>
                                <input type="text" placeholder="Rechercher" class="form-control" wire:model="search" wire:keyup="search_function" />
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Thématique</label>
                                <select class="form-control" wire:model="thematique" wire:change="search_function">
                                    <option value="">Tous</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $thematiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thematique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($thematique->id); ?>"><?php echo e($thematique->thematique); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Ville</label>
                                <select class="form-control" wire:model="ville" wire:change="search_function">
                                    <option value="">Tous</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ville->id); ?>"><?php echo e($ville->ville); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Département</label>
                                <select class="form-control" wire:model="departement" wire:change="search_function">
                                    <option value="">Tous</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $departements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($departement->id); ?>"><?php echo e($departement->departement); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Date début</label>
                                <input type="date" class="form-control" title="Date début" wire:model="f_date_debut" wire:change="search_function" />
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Date fin</label>
                                <input type="date" class="form-control" title="Date fin" wire:model="f_date_fin" wire:change="search_function" />
                            </div>
                        </div>
                        
                    </div>
                </form>
                

                <table class="custom-table w-100">
                    <thead>
                        <th>
                            <div class="custom-control custom-checkbox d-inline-block" style="width:30px">
                                <input type="checkbox" class="custom-control-input" id="select-all" wire:model="selectAll" wire:change="selectAllCheckBoxes">
                                <label class="custom-control-label" for="select-all"></label>
                            </div>
                        </th>
                        <th>Entreprise</th>
                        <th>Nom Prénom</th>
                        <th>Tel</th>
                        <th>Email</th>
                        <th>N° Identification</th>
                        <th>SIREN</th>
                        <th>SIRET</th>
                        <th>RCS</th>
                        <th>Désactiver / Activer</th>
                        <th>Détails</th>
                    </thead>
                    <tbody class="custom-striped">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>

                                <div class="custom-control custom-checkbox d-inline-block" style="width:30px">
                                    <input type="checkbox" class="custom-control-input checkbox-auto" id="client<?php echo e($lead->id); ?>"  value="<?php echo e($lead->id); ?>" wire:model="selectClients">
                                    <label class="custom-control-label" for="client<?php echo e($lead->id); ?>"></label>
                                </div>

                            </td>
                            <td><?php echo e($lead->entreprise); ?></td>
                            <td><?php echo e($lead->nom); ?> <?php echo e($lead->prenom); ?></td>
                            <td><?php echo e($lead->tel); ?></td>
                            <td><?php echo e($lead->email); ?></td>
                            <td><?php echo e($lead->numero_identification); ?></td>
                            <td><?php echo e($lead->siren); ?></td>
                            <td><?php echo e($lead->siret); ?></td>
                            <td><?php echo e($lead->rcs); ?></td>
                            <td>
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" wire:click="activation(<?php echo e($lead->activer); ?> , <?php echo e($lead->id); ?>)" id="activation<?php echo e($lead->id); ?>" <?php if($lead->activer): ?> checked <?php endif; ?>>
                                    <label class="custom-control-label" for="activation<?php echo e($lead->id); ?>"></label>
                                </div>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.client.show', $lead->id )); ?>" wire:navigate class="mr-1">
                                    <i class="fa-solid fa-pen-clip fa-lg text-secondary"></i>
                                </a>
                                <a href="#" title="Supprimer" wire:click="delete_client(<?php echo e($lead->id); ?>)">
                                    <i class="fa-solid fa-trash-can fa-lg text-danger"></i>
                                </a>
                            </td>
                        </tr>

                            <?php
                                array_push($this->selectClientsIds, $lead->id);
                            ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>

            <div class="d-flex mt-1 mx-2">
                <div class="btn-group" role="group"></div>
            </div>
            
        </div>
    </div>
</div>
<?php /**PATH C:\Users\USER\Desktop\leads-app-2\resources\views/livewire/admin/client/index.blade.php ENDPATH**/ ?>