<div>

    <?php $__env->startSection("title"); ?>
        Thématiques
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
    THÉMATIQUES
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("element"); ?>
        <button role="button" class="btn btn-primary px-1 add-modal">Ajouter Thématique</button>
    <?php $__env->stopSection(); ?>


    <div class="card">
        <div class="card-body py-1 px-0">

            <table class="custom-table w-100">
                <thead>
                    <th>Thématique</th>
                    <th>Type</th>
                    <th>Leads</th>
                    <th>Action</th>
                </thead>
                <tbody class="custom-striped">

                        <!--[if BLOCK]><![endif]--><?php if($thematiques->count() == 0): ?>
                            <tr>
                                <td colspan="5" class="text-center">Aucune thématique</td>
                            </tr>
                        <?php else: ?>

                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $thematiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $thematique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($thematique->thematique); ?></td>
                                    <td><?php echo e($thematique->type); ?></td>

                                    <td><?php echo e($thematique->leads_count); ?></td>
                                    <td>

                                        <a href="#" title="Modifier" wire:click="modifier_thematique(<?php echo e($thematique->id); ?>)">
                                            <i class="fa-solid fa-pen-clip fa-lg text-secondary mr-1"></i>
                                        </a>
                                        <a href="#" title="Supprimer" wire:click="delete_thematique(<?php echo e($thematique->id); ?>)">
                                            <i class="fa-solid fa-trash-can fa-lg text-danger"></i>
                                        </a>

                                    </td>  
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
              </div>
              <!-- Pagination Links -->
              <div class="d-flex  mt-1 mx-2">
                  <div class="btn-group" role="group">
                      <?php echo e($thematiques->links('pagination::bootstrap-4')); ?>

                  </div>
              </div>
          </div>

          <?php echo $__env->make('livewire.admin.thematique.ajouter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo $__env->make('livewire.admin.thematique.modifier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div><?php /**PATH D:\leads-app\resources\views/livewire/admin/thematique/index.blade.php ENDPATH**/ ?>