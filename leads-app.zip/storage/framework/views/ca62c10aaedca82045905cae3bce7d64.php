<div>

    <?php $__env->startSection("title"); ?>
        Ventes
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
        VENTES
    <?php $__env->stopSection(); ?>

    <div class="card">
            <div class="card-body py-1 px-0 overflow-auto">

                <form class="mb-3">

                    <div class="filters px-0">
                        
                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Rechercher</label>
                                <input type="text" placeholder="Rechercher" class="form-control" wire:model="search" wire:keyup="search_function" />
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Thématique</label>
                                <select class="form-control" wire:model="thematique" wire:change="search_function">
                                    <option value="">Tous</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $thematiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thematique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($thematique->id); ?>"><?php echo e($thematique->thematique); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Ville</label>
                                <select class="form-control" wire:model="ville" wire:change="search_function">
                                    <option value="">Tous</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ville->id); ?>"><?php echo e($ville->ville); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Département</label>
                                <select class="form-control" wire:model="departement" wire:change="search_function">
                                    <option value="">Tous</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $departements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($departement->id); ?>"><?php echo e($departement->departement); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Date début</label>
                                <input type="date" class="form-control" title="Date début" wire:model="f_date_debut" wire:change="search_function" />
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Date fin</label>
                                <input type="date" class="form-control" title="Date fin" wire:model="f_date_fin" wire:change="search_function" />
                            </div>
                        </div>
                        
                    </div>
                </form>
                        <table class="custom-table w-100">
                            <thead>
                                <th>Nom Prénom</th>
                                <th>Tel</th>
                                <th>Email</th>
                                <th>Reference</th>
                                <th>Thématique</th>
                                <th>Département</th>
                                <th>Prix</th>
                                <th>Détails</th>
                                <th>Action</th>
                            </thead>
                            <tbody class="custom-striped">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($lead->client->nom); ?> <?php echo e($lead->client->prenom); ?></td>
                                    <td><?php echo e($lead->client->tel); ?></td>
                                    <td><?php echo e($lead->client->email); ?></td>
                                    <td><?php echo e($lead->lead->reference); ?></td>
                                    <td><?php echo e(optional($lead->thematique)->thematique); ?></td>
                                    <td><?php echo e(optional($lead->departement)->departement); ?></td>
                                    <td><?php echo e($lead->lead->code_postale); ?></td>
                                    <td><?php echo e($lead->prix); ?></td>
                      
                                    <td>
                                        <a href="<?php echo e(route('admin.payment.show', $lead->id )); ?>" title="Show" wire:navigate>
                                            <i class="fa-solid fa-pen-clip fa-lg text-secondary"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-end mt-2 mx-2">
                            <div class="btn-group" role="group">
                            <?php echo e($leads->links('pagination::bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>
                </div>
</div><?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app\resources\views/livewire/admin/payment/index.blade.php ENDPATH**/ ?>