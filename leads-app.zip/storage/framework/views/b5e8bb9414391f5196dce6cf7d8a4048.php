          <div wire:ignore.self class="modal fade" id="addModal">
            <div class="modal-dialog" role="document">
              <div class="modal-content">

                
                <div class="w-100 text-center pt-3 mb-2">
                  <div class="w-100">
                    <div class="h3">Ajouter Département</div>
                  </div>
                </div>
          
                <form wire:submit="ajouter_departement" autocomplete="off">

                  <div class="modal-body pb-0">

                      <div class="row">

                      <div class="col-12">
                            <div class="form-group mb-1">
                                <label>N°</label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie N°" wire:model="num" autocomplete="off" />
                                <span class="error">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["num"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </span>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group mb-1">
                                <label>département</label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['departement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="saisie la departement" wire:model="departement" autocomplete="off" />
                                <span class="error">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["departement"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </span>
                            </div>
                        </div>

                      </div>

                  </div>

                  <div class="modal-footer">
                    <button type="submit" class="custom-btn" wire:loading.class="disabled">  
                        <div wire:loading><span class="spinner"></span></div>
                        <span wire:loading.remove>Ajouter</span>
                    </button>
                  </div>

                </form>
                
              </div>
            </div>
          </div>
          <!----------------- End Modal -----------------><?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app-2\resources\views/livewire/admin/departement/ajouter.blade.php ENDPATH**/ ?>