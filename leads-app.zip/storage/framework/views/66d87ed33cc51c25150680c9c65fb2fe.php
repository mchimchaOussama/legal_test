<div>

    <?php $__env->startSection("title"); ?>
        Comptes
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("page-title"); ?>
        COMPTES
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection("element"); ?>
        <a role="button" class="btn btn-primary" href="<?php echo e(route('admin.ajouter-compte')); ?>" wire:navigate>Ajouter un compte</a>
    <?php $__env->stopSection(); ?>

    <div class="card">
        <div class="card-body py-1 px-0">

            <table class="custom-table w-100">
                <thead>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Nom d'utilisateur</th>
                    <th>Role</th>
                    <th>Désactiver / Activer</th>
                    <th>Action</th>
                </thead>
                <tbody class="custom-striped">


                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->nom); ?></td>
                                <td><?php echo e($user->prenom); ?></td>
                                <td><?php echo e(ucfirst($user->nom_utilisateur)); ?></td>
                                <td><?php echo e(ucfirst($user->role->role)); ?></td>

                                <td>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" wire:click="activation(<?php echo e($user->activer); ?> , <?php echo e($user->id); ?>)" id="activation<?php echo e($user->id); ?>" <?php if($user->activer): ?> checked <?php endif; ?>>
                                        <label class="custom-control-label" for="activation<?php echo e($user->id); ?>"></label>
                                    </div>
                                </td>
                                <td>
                                    <a href="#" title="Modifier" class="edit-modal" wire:click="modifier_user(<?php echo e($user->id); ?>)" >
                                        <i class="fa-solid fa-pen-clip fa-lg text-secondary mr-1"></i>
                                    </a>
                                    <a href="#" title="Supprimer" wire:click="delete_user(<?php echo e($user->id); ?>)">
                                        <i class="fa-solid fa-trash-can fa-lg text-danger"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                </tbody>
            </table>


            <div class="d-flex justify-content-end align-items-center mt-2 px-2">
                <a class="btn btn-secondary mr-1 btn-pagination" href="<?php echo e($users->previousPageUrl()); ?>" wire:navigate>Précédent</a>
                <a class="btn btn-secondary btn-pagination" href="<?php echo e($users->nextPageUrl()); ?>" wire:navigate>Suivant</a>
            </div>

        </div>
    </div>


    <?php echo $__env->make('livewire.admin.administrateurs.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div><?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app-2\resources\views/livewire/admin/administrateurs/index.blade.php ENDPATH**/ ?>