<div>

    <?php $__env->startSection("title"); ?>
    Paramètres
    <?php $__env->stopSection(); ?>

    <div class="h2 fw-bold">PARAMÈTRES</div>

    <div class="card mb-3">
        <div class="card-body">

            <h5 class="card-title mb-1">LOGO</h5>

            <div class="media">
                <a href="javascript:void(0);" class="mr-25">
                    <img src="<?php echo e(asset('/assets/images/produit.png')); ?>" id="account-upload-img" class="rounded mr-50" alt="profile image" height="80" width="80" />
                </a>
                <!-- upload and reset button -->
                <div class="media-body mt-75 ml-1">
                    <label for="account-upload" class="btn btn-sm btn-primary mb-75 mr-75">Télécharger</label>
                    <input type="file" id="account-upload" hidden accept="image/png, image/jpg, image/jpeg" wire:model="profil_file" />
                    <button class="btn btn-sm btn-outline-secondary mb-75" wire:click="supprimer_profil">Supprimer</button>
                    <p>JPG, JPEG ou PNG autorisé.</p>
                </div>
                <!--/ upload and reset button -->
            </div>
            
        </div>
    </div>


    <div class="card mb-3">
        <form wire:submit="contact_info" class="px-0" autocomplete="off">
            <div class="card-body">

            <h5 class="card-title mb-3">Coordonnées</h5>

                <div class="col-xl-5 col-lg-6 col-md-10 col-sm-12 px-0">
                    <div class="form-group">
                        <label for="email">E-mail</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="Saisie l'email" autocomplete="off" wire:model="email">
                        <span class="error">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </span>
                    </div>
                </div>
                <div class="col-xl-5 col-lg-6 col-md-10 col-sm-12 px-0">
                    <div class="form-group">
                        <label for="tel">Tel</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tel" placeholder="Saisie tel" autocomplete="off" wire:model="tel">
                        <span class="error">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["tel"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </span>
                    </div>
                </div>
                <div class="col-xl-5 col-lg-6 col-md-10 col-sm-12 px-0">
                    <div class="form-group mb-1">
                        <label for="adresse">Adresse</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="adresse" placeholder="Saisie l'adresse" autocomplete="off" wire:model="adresse">
                        <span class="error">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["adresse"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </span>
                    </div>
                </div>

                <button type="submit" class="custom-btn" wire:loading.class="disabled">  
                    <div wire:loading><span class="spinner"></span></div>
                    <span wire:loading.remove>Modifier</span>
                </button>

            </div>

        </form>
    </div>


    <div class="card mb-3">
        <form wire:submit="mailer" class="px-0" autocomplete="off">
            <div class="card-body">

                <h5 class="card-title mb-3">Paramètres du Mailer</h5>

                <div class="col-xl-5 col-lg-6 col-md-10 col-sm-12 px-0">
                    <div class="form-group">
                        <label for="host">Host</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="host" placeholder="Host" autocomplete="off" wire:model="email">
                        <span class="error">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["host"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </span>
                    </div>
                </div>
                <div class="col-xl-5 col-lg-6 col-md-10 col-sm-12 px-0">
                    <div class="form-group">
                        <label>Nom d'utilisateur</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Saisie le nom d'utilisateur" autocomplete="off" wire:model="tel">
                        <span class="error">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["username"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </span>
                    </div>
                </div>
                <div class="col-xl-5 col-lg-6 col-md-10 col-sm-12 px-0">
                    <div class="form-group mb-1">
                        <label>Mot de passe</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Saisie le mot de passe" autocomplete="off" wire:model="password">
                        <span class="error">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </span>
                    </div>
                </div>

                <div class="col-xl-5 col-lg-6 col-md-10 col-sm-12 px-0">
                    <div class="form-group mb-1">
                        <label>Port</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Saisie le port" autocomplete="off" wire:model="port">
                        <span class="error">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["port"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </span>
                    </div>
                </div>

                <button type="submit" class="custom-btn" wire:loading.class="disabled">  
                    <div wire:loading><span class="spinner"></span></div>
                    <span wire:loading.remove>Modifier</span>
                </button>

            </div>

        </form>
    </div>


</div>
<?php /**PATH C:\Users\TECHNOLOGICA\Desktop\leads-app-2\resources\views/livewire/admin/config/index.blade.php ENDPATH**/ ?>