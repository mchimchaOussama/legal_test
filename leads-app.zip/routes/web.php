<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\checkAuth;
use App\Http\Middleware\alreadyAuth;
use App\Http\Middleware\Superviseur;

use App\Http\Controllers\AdminLoginController;
use App\Http\Controllers\pypalController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\clientDashbordController;


use Illuminate\Support\Facades\DB;
use App\Http\Controllers\MailingController;



///////////// Accueil //////////////
use App\Livewire\Admin\Accueil as Admin_Acceuil;

////////////// Thematiques ////////////
use App\Livewire\Admin\Thematique\Index as Thematique_Index;

////////////// Departement ////////////
use App\Livewire\Admin\Departement\Index as Departement_Index;

////////////// Departement ////////////
use App\Livewire\Admin\Ville\Index as Ville_Index;
///////////////// Administrateur ////////////////////

////////////// lead ////////////
use App\Livewire\Admin\Lead\Index as Lead_Index;

////////////// Ajouter Lead ////////////
use App\Livewire\Admin\LeadAjouter\Index as Lead_Ajouter_Index;

//////// Comptes /////////
use App\Livewire\Admin\Administrateurs\Index as Adminisrateurs_Index;

/////// Ajouter Compte //////
use App\Livewire\Admin\AjouterAdministrateur\Index as AjouterAdminisrateur_Index;

////////////// lead ////////////
use App\Livewire\Admin\Profil\Index as Profil_Index;

////////////// lead ////////////
use App\Livewire\Admin\LeadModifier\Index as LeadModifier_Index;

////////////// Config ////////////
use App\Livewire\Admin\Config\Index as Config_Index;

////////////// Payment ////////////
use App\Livewire\Admin\Payment\Index as Payment_Index;
use App\Livewire\Admin\Payment\Show\Index as Payment_Show_Index;

////////////// Client ////////////
use App\Livewire\Admin\Client\Index as Client_Index;
use App\Livewire\Admin\Client\Show\Index as Client_Show_Index;

//////////// Statistics /////////////
use App\Livewire\Admin\Statistics\Index as Statistics_Index;

//////////// Coupon /////////////
use App\Livewire\Admin\Coupon\Index as Coupon_Index;
use App\Livewire\Admin\CouponAjouter\Index as Coupon_Ajouter_Index;

/////////////marketplace///////////////////////////////////////////

use App\Livewire\Marketplace\client\register as marketplace_register;


/////////////Corbeille///////////////////////////////////////////

use App\Livewire\Admin\Corbeille\index as Admin_Corbeille;



Route::middleware([alreadyAuth::class])->group(function(){


    Route::get("/admin/login", function(){
        return view("login.index");
    })->name('admin.login-view');

    
    Route::post("/admin/login-post", [AdminLoginController::class, "login_post"])->name("admin.login-post");

});


Route::middleware([checkAuth::class, Superviseur::class])->group(function(){

    ////////// Comptes ////////
    Route::get('/admin/comptes', Adminisrateurs_Index::class)->name('admin.comptes');

    /////////// Ajouter un compte ////////////
    Route::get('/admin/ajouter-compte', AjouterAdminisrateur_Index::class)->name('admin.ajouter-compte');

    //////// Payment //////////
    Route::get('/admin/payment', Payment_Index::class)->name('admin.payment');
    Route::get('/admin/payment/details/{leadId}', Payment_Show_Index::class)->name('admin.payment.show');

    /////// Configuration /////
    Route::get("/admin/config", Config_Index::class)->name("admin.config");

    //////// Client //////////
    Route::get('/admin/client', Client_Index::class)->name('admin.client');
    Route::get('/admin/client/details/{leadId}', Client_Show_Index::class)->name('admin.client.show');

    //////// Statistics ////////
    Route::get('/admin/statistics', Statistics_Index::class)->name("admin.statistics");

    Route::get("/admin/coupon", Coupon_Index::class)->name("admin.coupon");
    Route::get("/admin/coupon-ajouter", Coupon_Ajouter_Index::class)->name("admin.coupon-ajouter");

});


Route::middleware([checkAuth::class])->group(function(){


    ///////// Accueil /////////
    Route::get('/admin/accueil', Admin_Acceuil::class)->name('admin.accueil');


    //////////// Ajouter Lead ////////////
    Route::get('/admin/leads', Lead_Index::class)->name('admin.lead');

    Route::get('/admin/corbeille', Admin_Corbeille::class)->name('admin.corbeille');

    

    Route::get('/admin/lead-ajouter', Lead_Ajouter_Index::class)->name('admin.lead-ajouter');
    Route::get('/admin/lead-modifier/{leadId}', LeadModifier_Index::class)->name('admin.lead-modifier');

    ///////////// Admin Logout //////////
    Route::get("/admin/logout", [AdminLoginController::class, "logout"])->name("admin.logout");

    ////////// Profil /////////
    Route::get("/admin/profil", Profil_Index::class)->name("admin.profil");

    //////// Thematique ////////
    Route::get('/admin/thematiques', Thematique_Index::class)->name('admin.thematiques');
    Route::get('/admin/departement', Departement_Index::class)->name('admin.departement');
    Route::get('/admin/ville', Ville_Index::class)->name('admin.ville');


});

Route::post('/pypal/post', [pypalController::class ,'pypal'])->name('pypal.post');
Route::get('/pypal/get/success', [pypalController::class,'success'])->name('success');
Route::get('/pypal/get/cancel', [pypalController::class,'cancel'])->name('cancel');
Route::get('/pypal/get/page', [pypalController::class,'index' ])->name('pypal.page');






Route::get("/", [HomeController::class, "get_home"])->name("get.home");
Route::get('/get-leads', [HomeController::class, 'getLeads']);
///////////marketplace///////////////////////////////

Route::get("/marketplace/marketplace", [HomeController::class, "marketplace_get"])->name("get.marketplace");
Route::post("/marketplace/marketplace", [HomeController::class, "marketplace_filter"])->name("post.marketplace");
Route::get("/marketplace/detai/{id}", [HomeController::class, "detai_get"])->name("get.detai");
Route::get("/marketplace/faq", [HomeController::class, "get_faq"])->name("get.faq");
Route::get('/marketplace/register', [HomeController::class, "get_register"])->name('get.register.marketplace');

Route::get('/api/get-departements', [HomeController::class, 'getDepartements']);
Route::get('/api/get-villes', [HomeController::class, 'getVilles']);
Route::get('/api/get-thematiques', [HomeController::class, 'getThematiques']);
Route::get('/api/get-selected-departements', [HomeController::class, 'getSelectedDepartements']);
Route::get('/api/get-selected-thematiques', [HomeController::class, 'getSelectedThematiques']);

Route::post('/api/register', [HomeController::class, 'furstStepRegister']);
Route::post('/api/login', [HomeController::class, 'login']);
Route::post('/logout', [HomeController::class, 'logout'])->name('logout');
Route::post('/track-view', [HomeController::class, 'trackLeadView'])->name('track.view');
///////////////////dashbord//////////////////////////////////////////
Route::get("/dashbord/client", [clientDashbordController::class, "dashbord_get"])->name("get.dashbord.client");
Route::get('/fetch-leads', [clientDashbordController::class, 'fetchLeads']);
Route::post('/profil/client', [clientDashbordController::class, 'update'])->name('update.profil.client');

Route::get("/send", [MailingController::class, "send_mail"]);

Route::post("/client/reset-password", [clientDashbordController::class, "get_resetPassword"])->name("get.reste.password");

Route::get("/update-password/{id}", [clientDashbordController::class, "get_newPassword"])->name("password.reset");

Route::post("/update-new-password", [clientDashbordController::class, "update_new_password"]);

Route::post('/send-verification-code', [clientDashbordController::class, 'sendVerificationCode']);


