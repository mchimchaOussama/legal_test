import './bootstrap';
// resources/js/app.js

import './../../vendor/power-components/livewire-powergrid/dist/powergrid'
// resources/js/app.js

import './../../vendor/power-components/livewire-powergrid/dist/tailwind.css'
// resources/js/app.js

import './../../vendor/power-components/livewire-powergrid/dist/bootstrap5.css'