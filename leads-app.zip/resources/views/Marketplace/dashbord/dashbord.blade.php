@extends('components.app_client') 
@section('title', 'dashbord') 
@section('content')

<!DOCTYPE html>

<body class="body bg-surface">

    <div class="preload preload-container">
        <div class="boxes ">
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
            <div class="box">
                <div></div> <div></div> <div></div> <div></div>
            </div>
        </div>
    </div>
    
    <!-- /preload -->

    <div id="wrapper">
        <div id="page" class="clearfix">
            <div class="layout-wrap">
                <!-- header -->
                <header class="main-header fixed-header header-dashboard">
                    <!-- Header Lower -->
                    <div class="header-lower">
                        <div class="row">                      
                            <div class="col-lg-12">         
                                <div class="inner-container d-flex justify-content-between align-items-center">
                                    <!-- Logo Box -->
                                    <div class="logo-box d-flex">
                                        <div class="logo">  <a class="navbar-brand ms-5" href="index.html"><img src="{{ asset('assetsMarketplace/images/logo.png') }}"  width="174" height="44"     alt="logo"  /></a></div>
                                        <div class="button-show-hide">
                                            <span class="icon icon-categories"></span>
                                        </div>
                                    </div>
                                    <div class="nav-outer">
                                        <!-- Main Menu -->
                                        <nav class="main-menu show navbar-expand-md">
                                            <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                                                <ul class="navigation clearfix">
                                                <li class=" home "><a href="{{route('get.home')}}">Accueil</a>

                                                <li class="dropdown2"><a href="#">Thematique</a>
                                                    <ul>
                                                        @foreach($thematiques as $thematique)
                                                        <li><a href="{{route('get.marketplace')}}">{{$thematique->thematique}}</a></li>
                                                        @endforeach
                                                    </ul>
                                                </li>
                                                <li class=""><a href="{{route('get.marketplace')}}">Marketplace</a>
                                                </li>
                                                <li class=""><a href="#">A Propos</a>
                                                </li>
                                                <li class=""><a href="{{route('get.faq')}}">FAQ</a>
                                                </li>
                                                    
                                                @if(session()->has('client_hom'))

                                                <li class="dropdown2"><a href="#">Bienvenue, {{ session('client_hom')->nom }}</a>
                                                    <ul>
                                                        <li><a href="dashboard.html">Dashboard</a></li>
                                                        <li><a href="my-favorites.html">My Properties</a></li>
                                                        <li><a href="my-invoices.html">My Invoices</a></li>
                                                        <li><a href="my-favorites.html">My Favorites</a></li>
                                                        <li><a href="reviews.html">Reviews</a></li>
                                                        <li><a href="my-profile.html">My Profile</a></li>
                                                        <li><a href="add-property.html">Add Property</a></li>
                                                        <li> 
                                                        <a href="#">
                                                        <form action="{{ route('logout') }}" method="POST" style="display: inline;">
                                                            @csrf
                                                            <button type="submit" style="border: none; background: none;  cursor: pointer;">
                                                                déconnecter
                                                            </button>
                                                        </form>
                                                        </a>

                                                        </li>
                                                    </ul>
                                                </li>
                                                @endif
                                                </ul>
                                            </div>
                                        </nav>
                                        <!-- Main Menu End-->
                                    </div>
                                    <div class="header-account">

                                    </div>
                                    
                                    <div class="mobile-nav-toggler mobile-button"><span></span></div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Header Lower -->
                
                    <!-- Mobile Menu  -->
                    <div class="close-btn"><span class="icon flaticon-cancel-1"></span></div>    
                    <div class="mobile-menu">
                        <div class="menu-backdrop"></div>                            
                        <nav class="menu-box">
                            <div class="nav-logo"><a href="index.html"><img src="images/logo/logo%402x.png" alt="nav-logo" width="174" height="44"></a></div>
                            <div class="bottom-canvas">
                                <div class="menu-outer"></div>
                                <div class="button-mobi-sell">
                                    <a class="tf-btn primary" href="add-property.html">Submit Property</a>
                                </div> 
                                <div class="mobi-icon-box">
                                    <div class="box d-flex align-items-center">
                                        <span class="icon icon-phone2"></span>
                                        <div>1-333-345-6868</div>
                                    </div>
                                    <div class="box d-flex align-items-center">
                                        <span class="icon icon-mail"></span>
                                        <div>themesflat@gmail.com</div>
                                    </div>
                                </div>
                            </div>
                        </nav>                
                    </div>
                    <!-- End Mobile Menu -->
                
                </header>
                <!-- end header -->
                <!-- sidebar dashboard -->
                <div class="sidebar-menu-dashboard">
                    <ul class="box-menu-dashboard">
                        <li class="nav-menu-item active"><a class="nav-menu-link" href="dashboard.html"><span class="icon icon-dashboard"></span> Dashboards</a></li>
                        <li class="nav-menu-item"><a class="nav-menu-link" href="reviews.html"><span class="icon icon-review"></span> Reviews</a></li>
                        <li class="nav-menu-item "><a class="nav-menu-link" href="my-profile.html"><span class="icon icon-profile"></span> My Profile</a></li>
                        <li class="nav-menu-item"><a class="nav-menu-link" href="index.html"><span class="icon icon-sign-out"></span> Logout</a></li>
                    </ul>
                </div>
                <!-- end sidebar dashboard -->
                <div class="main-content">
                    <div class="main-content-inner wrap-dashboard-content-2">
                    <div class="button-show-hide show-mb">
                            <span class="body-1">Show Dashboard</span>
                        </div>
                        <div class="flat-counter-v2 tf-counter">
                            <div class="counter-box">
                                <div class="box-icon w-68 round">
                                    <span class="icon icon-list-dashes"></span>
                                </div>
                                <div class="content-box">
                                    <div class="title-count">Lead acheter  </div>
                                    <div class="d-flex align-items-end">
                                        <h6 class="number" data-speed="2000" data-to="17" data-inviewport="yes">17</h6>                                   
                                        <span class="fw-7 text-variant-2">/17 remaining</span>
                                    </div>                              

                                </div>
                            </div>
                            <div class="counter-box">
                                <div class="box-icon w-68 round">
                                    <span class="icon icon-clock-countdown"></span>
                                </div>
                                <div class="content-box">
                                    <div class="title-count">Total acheter </div>
                                    <div class="d-flex align-items-end">
                                        <h6 class="number" data-speed="2000" data-to="0" data-inviewport="yes">0</h6>                                   
                                    </div>                              

                                </div>
                            </div>
                            <div class="counter-box">
                                <div class="box-icon w-68 round">
                                    <span class="icon icon-bookmark"></span>
                                </div>
                                <div class="content-box">
                                    <div class="title-count">Leat visiter </div>
                                    <div class="d-flex align-items-end">
                                        <h6 class="number" data-speed="2000" data-to="1" data-inviewport="yes">1</h6>                                   
                                    </div>                              

                                </div>
                            </div>
                        </div>
                        <div class="wrapper-content row">
                            <div class="col-xl-12">
                                <div class="widget-box-2 wd-listing">
                                    <h6 class="title">New Listing</h6>
                                    <div class="wd-filter">
                                    <div class="ip-group">
                                <label for="select-thematique">Thématique</label>
                                <select name="thematique_id" id="select-thematique" class="form-select">
                                    <option selected disabled>Selecter Thématique</option>
                                    @foreach($thematiques as $thematique) 
                                        <option value="{{ $thematique->id }}">{{ $thematique->thematique }}</option> 
                                    @endforeach
                                </select>
                            </div>

                            <div class="ip-group">
                                <label for="select-departement">Département</label>
                                <select name="departement_id" id="select-departement" class="form-select">
                                    <option selected disabled>Selecter Département</option>
                                    @foreach($departements as $departement) 
                                        <option value="{{ $departement->id }}">{{ $departement->departement }}</option> 
                                    @endforeach
                                </select>
                            </div>

                            <div class="ip-group">
                                <label for="date_debut">Date Début</label>
                                <input type="date" id="date_debut" class="form-control" style="height: 38px;">
                            </div>

                            <div class="ip-group">
                                <label for="date_fin">Date Fin</label>
                                <input type="date" id="date_fin" class="form-control" style="height: 38px;">
                            </div>

                            <button id="fetch-leads" class="btn btn-primary">Chercher</button>
                                  
                                    </div>
                                    <div class="d-flex gap-4"><span class="text-primary fw-7">17</span><span class="text-variant-1">Results found</span></div>
                                    <div class="wrap-table">
                                        <div class="table-responsive">

                                        <table id="leads_table">
                                            <thead>
                                                <tr>
                                                    <th>Lead</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!-- Leads will be dynamically inserted here -->
                                            </tbody>
                                        </table>

                                        <ul id="pagination" class="pagination">
                                            <!-- Pagination links will be dynamically inserted here -->
                                        </ul>

                                        </div>

                                    </div>
                                </div>
                                <div class="widget-box-2 wd-chart">
                                    <h6 class="title">Page Inside</h6>
                                    <div class="wd-filter-date">
                                        <div class="left">
                                            <div class="dates active">Day</div>
                                            <div class="dates">Week</div>
                                            <div class="dates">Month</div>
                                            <div class="dates">Year</div>
                                        </div>
                                        <div class="right">
                                            <div class="ip-group icon">
                                                <input type="text" id="datepicker3" class="ip-datepicker icon" placeholder="From Date">
                                            </div>
                                            <div class="ip-group icon">
                                                <input type="text" id="datepicker4" class="ip-datepicker icon" placeholder="To Date">
                                            </div>
                                        </div>
                                        
                                        
                                    </div>
                                    <div class="chart-box">
                                        <canvas id="lineChart"></canvas>
                                    </div>
                                </div>
                            </div>

                        </div>
                

                    <div class="footer-dashboard">
                        <p class="text-variant-2">©2024 Homzen. All Rights Reserved.</p>
                    </div>
                </div>

                <div class="overlay-dashboard"></div>

            </div>
        </div>
        <!-- /#page -->

    </div>
    <!-- go top -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 286.138;"></path>
        </svg>
    </div>





<script>
$(document).ready(function() {
    // Function to fetch leads with optional filters
    function fetchLeads(page = 1) {
        const thematiqueId = $('#select-thematique').val();
        const departementId = $('#select-departement').val();
        const dateDebut = $('#date_debut').val();
        const dateFin = $('#date_fin').val();

        $.ajax({
            url: '/fetch-leads',
            method: 'GET',
            data: {
                page: page,
                thematique_id: thematiqueId,
                departement_id: departementId,
                date_debut: dateDebut,
                date_fin: dateFin
            },
            success: function(response) {
                const leads = response.leads.data;
                const totalPages = response.leads.last_page;

                // Clear previous leads
                $('#leads_table tbody').empty();

                // Check if there are any leads
                if (leads.length === 0) {
                    $('#leads_table tbody').append(`
                        <tr>
                            <td colspan="3" class="text-center">Aucun paiement trouvé.</td>
                        </tr>
                    `);
                } else {
                    // Populate leads
                    leads.forEach(lead => {
                        $('#leads_table tbody').append(`
                            <tr>
                                <td>${lead.prix} - ${lead.consumption_mode}</td>
                                <td>${lead.status}</td>
                                <td>
                                    <a class="btn btn-info">Details</a>
                                </td>
                            </tr>
                        `);
                    });
                }

                // Clear previous pagination
                $('#pagination').empty();

                // Populate pagination
                for (let i = 1; i <= totalPages; i++) {
                    $('#pagination').append(`
                        <li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>
                    `);
                }

                // Attach click event to pagination links
                $('#pagination .page-link').on('click', function(e) {
                    e.preventDefault();
                    const page = $(this).data('page');
                    fetchLeads(page);
                });
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }

    // Fetch all leads on initial load
    fetchLeads();

    // Fetch leads on filter change
    $('#fetch-leads').on('click', function() {
        fetchLeads();
    });
});


    $(document).ready(function() {
        $('.button-show-hide').on('click', function() {
            $('.layout-wrap').toggleClass('full-width'); // Toggles the full-width class on and off
        });
    });

</script>

<!-- Mirrored from themesflat.co/html/homzen/my-invoices.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 14 Oct 2024 22:36:10 GMT -->
</html>


@endsection